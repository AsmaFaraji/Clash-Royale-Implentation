//
// Created by asma on 6/27/16.
//

#include <QtCore/qsize.h>
#include <QtCore/qstring.h>
#include <Sources/HeaderFiles/MyData.h>

namespace MyData {


    //Addresses
    const QString wlcm_img_add("Resources/Background-img/clash-welcome.jpg");
    const QString bckgrnd_img_add("Resources/Background-img/main-background.jpg");
    const QString sttng_img_add("Resources/Background-img/untitled-1.jpg");
    const QString ext_img_add("Resources/Background-img/untitled-3.jpg");
    const QString strt_img_add("Resources/Background-img/untitled-6.jpg");
    const QString help_img_add("Resources/Background-img/untitled-2.jpg");
    const QString choseCard_img_add("Resources/Background-img/untitled-4.jpg");
    const QString music_add("Resources/Music/themsong.mp3");
    const QString pause_bckgrnd_img_add("Resources/Background-img/pause-background.jpg");
    const QString card_add[15] = {"Resources/Cards/1.png", "Resources/Cards/2.png", "Resources/Cards/3.png",
                                  "Resources/Cards/4.png",
                                  "Resources/Cards/5.png", "Resources/Cards/6.png", "Resources/Cards/7.png",
                                  "Resources/Cards/8.png", "Resources/Cards/9.png",
                                  "Resources/Cards/10.png", "Resources/Cards/11.png", "Resources/Cards/12.png",
                                  "Resources/Cards/13.png", "Resources/Cards/14.png",
                                  "Resources/Cards/15.png"};
    const QString card_name[15] = {"ICE WIZARD", "WITCH", "ZAP", "RAGE", "INFERNO TOWER", "USING FURNANCE",
                                   "LAVA HOUND", "MINER",
                                   "VALKYRIE", "MIRROR", "DARKPRINCE", "ROYALGIANT", "BALLOON", "HOGRIDER",
                                   "MINION HORDE"};


    const QString map_add[6] = {"Resources/map_img/gr.jpg", "Resources/map_img/river.png",
                                "Resources/map_img/bridge.png",
                                "Resources/map_img/bridge.png", "Resources/map_img/bridge.png",
                                "Resources/map_img/bridge.png"};

    const QString stower_add[6] = {"Resources/tower_img/myarenatower.png", "Resources/tower_img/mykingtower.png",
                                   "Resources/tower_img/myarenatower.png", "Resources/tower_img/arenatower.png",
                                   "Resources/tower_img/kingtower.png", "Resources/tower_img/arenatower.png"};

    const QString dtower_add[10] = {"Resources/tower_img/myarenatower.png", "Resources/tower_img/myarenatower.png",
                                    "Resources/tower_img/mykingtower.png", "Resources/tower_img/myarenatower.png",
                                    "Resources/tower_img/myarenatower.png", "Resources/tower_img/arenatower.png",
                                    "Resources/tower_img/arenatower.png", "Resources/tower_img/kingtower.png",
                                    "Resources/tower_img/arenatower.png",
                                    "Resources/tower_img/arenatower.png"};


};
