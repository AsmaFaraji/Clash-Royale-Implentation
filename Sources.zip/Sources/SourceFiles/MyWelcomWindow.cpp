//
// Created by asma on 6/26/16.
//

#include <QtWidgets/qlabel.h>
using namespace std;
#include <iostream>
#include <QtWidgets/qboxlayout.h>
#include <Sources/HeaderFiles/MyWelcomWindow.h>
#include <Sources/HeaderFiles/MyData.h>

MyWelcomWindow::MyWelcomWindow()
{
    setFixedSize(1000, 630);
    loadImage();
    setQprogressBar();
    setLayout();
    show();

}

void MyWelcomWindow::loadImage()
{
    wlcomImage = new QLabel(this);
    wlcomImage -> setPixmap(QPixmap(MyData::wlcm_img_add));
    wlcomImage -> setAlignment(Qt::AlignCenter);
    wlcomImage -> setAttribute(Qt::WA_TranslucentBackground);
    wlcomImage -> setGeometry(MyData::wlcm_img);
    cout << this->height() << endl;
}

void MyWelcomWindow::setQprogressBar()
{
    progressbar = new QProgressBar(this);
    timer  = new QTimer();
    progressbar ->setMinimum(0);
    progressbar -> setMaximum(100);
    progressbar -> setOrientation(Qt:: Horizontal);


   // progressbar->setPalette(p);
    progressbar -> show();
    progressbar -> setStyleSheet("QProgressBar::chunk {\n"
                                 "        text-align: center;"
                                 "    background-color: #05B8CC;\n"
                                 "    width: 20px;\n"


                                 "}");
   /* progressbar -> setStyleSheet("QProgressBar {\n"
                                         "    background-color: black;\n"
                                         "    border: 2px solid grey;\n"
                                         "    border-radius: 5px;\n"
                                         "    text-align: center;\n"
                                         "}");*/
    connect(timer, SIGNAL(timeout()), this, SLOT(onTimeOut()));
    timer->start(200);

}

void MyWelcomWindow::onTimeOut()
{
    int value = progressbar -> value();
    progressbar -> setValue(++ value);
    if(value == 101)
        close();

}

void MyWelcomWindow:: setLayout()
{
    QWidget *centre = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout();
    layout -> addWidget(wlcomImage);
    layout -> addWidget(progressbar);
    setStyleSheet("QMainWindow {background: 'black';}");
    setCentralWidget(centre);
    centre -> setLayout(layout);
    setWindowTitle(":p");
}