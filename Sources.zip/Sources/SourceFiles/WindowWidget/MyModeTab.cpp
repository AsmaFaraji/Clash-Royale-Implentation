//
// Created by asma on 6/29/16.
//

#include "Sources/HeaderFiles/WindowWidget/MyModeTab.h"
MyModeTab::MyModeTab(QWidget *parent, Qt::WindowFlags f) :
        QWidget(parent, f)
{
    setRadiobtn();
    setLayout();
    show();
}

void MyModeTab::setRadiobtn() {
    sngl = new QRadioButton("1 - 1");
    QPalette* palette = new QPalette();
    palette->setColor(QPalette::Foreground,Qt::red);
    sngl->setPalette(*palette);
    sngl ->setStyleSheet("color: yellow");
    sngl -> setFont(QFont("Purisa", 20, QFont::Bold,true));
    sngl ->setChecked(true);

    dble = new QRadioButton("2-2");
    dble ->setStyleSheet("color: yellow");
    dble -> setFont(QFont("Purisa", 20, QFont::Bold,true));

    gmeMode = new QLabel("GAME MODE");
    gmeMode -> setStyleSheet("color: rgb(2, 165, 241)");
    gmeMode -> setFont(QFont("Purisa", 30, QFont::Bold,true));
}

void MyModeTab::setLayout() {
    group = new QGroupBox(this);
    layout = new QVBoxLayout();
    layout -> addWidget(gmeMode);
    layout -> addWidget(sngl);
    layout -> addWidget(dble);
    group -> setLayout(layout);



}
MyModeTab::~MyModeTab() {
    delete sngl;
    delete dble;
    delete group;
    delete layout;
    delete(gmeMode);
}