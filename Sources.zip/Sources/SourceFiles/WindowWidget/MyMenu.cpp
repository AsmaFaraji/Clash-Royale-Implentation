//
// Created by asma on 6/28/16.
//

#include <Sources/HeaderFiles/MyData.h>
#include "Sources/HeaderFiles/WindowWidget/MyMenu.h"
MyMenu::MyMenu() {
    setGeometry(MyData::mymainwindow_rec);
    load_image();
    setBtn();
    setLinEdit();
    show();
}

void MyMenu::setLinEdit() {
    name = new QLabel("NAME:", this);
    name-> setFont(QFont("lucida", 15, QFont::Bold, true));
    name-> setGeometry(MyData:: namelbl_rec);


    myName = new QLineEdit(this);
    myName -> setGeometry(MyData::namelnedit_rec);
    myName -> setStyleSheet("QLineEdit:!focus\n"
                                    "{\n"
                                    "  border: 1px solid transparent;\n"
                                    "  background: transparent;\n"
                                    "}");
    myName -> setText("ASMA");
}

void MyMenu::setBtn() {
    exit = new QPushButton("Exit",this);
    exit -> setGeometry(MyData::exitbtn_rec);
    exit -> setFont(QFont("Purisa", 20,QFont::Bold,true));
    exit ->setAutoFillBackground( true );
    exit ->setStyleSheet("background-color: rgb(2, 165, 241); color: rgb(0, 0, 0)");

    start = new QPushButton("Start",this);
    start -> setGeometry(MyData::startbtn_rec);
    start -> setFont(QFont("Purisa", 20, QFont::Bold,true));
    start ->setStyleSheet("background-color: rgb(2, 165, 241); color: rgb(0, 0, 0)");


    choseCard = new QPushButton("Cards", this);
    choseCard ->setGeometry(MyData::chosecardbtn_rec);
    choseCard -> setFont(QFont("Purisa", 20, QFont::Bold,true));
    choseCard ->setStyleSheet("background-color: rgb(2, 165, 241); color: rgb(0, 0, 0)");
    //choseCard->setStyleSheet(MyData::btn_stl);
//05A5F1
   // r = 5 g = 165 , b = 241;
    about = new QPushButton("About", this);
    about -> setGeometry(MyData::aboutbtn_rec);
    about-> setFont(QFont("Purisa", 20,QFont::Bold,true));
    about ->setStyleSheet("background-color: rgb(2, 165, 241); color: rgb(0, 0, 0)");

    setting = new QPushButton("Setting",this);
    setting -> setGeometry(MyData::settngbtn_rec);
    setting-> setFont(QFont("Purisa", 20, QFont::Bold,true));
    setting ->setStyleSheet("background-color: rgb(2, 165, 241); color: rgb(0, 0, 0)");
}
void MyMenu::load_image() {
    bckgrnd_img1 = new QLabel(this);
    bckgrnd_img1 -> setPixmap(QPixmap(MyData::bckgrnd_img_add).scaled(1000,700));
    bckgrnd_img1 -> setAlignment(Qt::AlignCenter);
    bckgrnd_img1 -> setAttribute(Qt::WA_TranslucentBackground);
    bckgrnd_img1 -> setGeometry(MyData::bckgrnd_img_rec);
}
MyMenu::~MyMenu() {
    delete start;
    delete setting;
    delete exit;
    delete choseCard;
    delete about;
    delete(myName);
    delete(bckgrnd_img1);
    delete(name);
}