//
// Created by asma on 7/2/16.
//

#include <Sources/HeaderFiles/MyData.h>
#include "Sources/HeaderFiles/WindowWidget/MyPause.h"

MyPause::MyPause() {
    setGeometry(MyData::bckgrnd_img_rec);
    loadImage();
    setBtn();
    show();

}
void MyPause::loadImage() {
   background = new QLabel(this);
    background -> setPixmap(QPixmap(MyData::pause_bckgrnd_img_add).scaled(1000, 700));
    background -> setAlignment(Qt::AlignCenter);
    background -> setAttribute(Qt::WA_TranslucentBackground);
    background -> setGeometry(MyData::bckgrnd_img_rec);
}

void MyPause::setBtn() {
    resume  = new QPushButton("RESUME", this);
    resume->setGeometry(MyData::resume_rec);
    resume -> setFont(QFont("Purisa", 20, QFont::Bold,true));
    resume ->//setStyleSheet("QPushButton{background:transparent;color : rgb (2, 165, 241)}");
            setStyleSheet("background-color: rgb(2, 165, 241); color: rgb(0, 0, 0)");


   exit = new QPushButton("QUIT", this);
   exit ->setGeometry(MyData::quit_rec);
   exit -> setFont(QFont("Purisa", 20, QFont::Bold,true));
   exit ->setStyleSheet("background-color: rgb(2, 165, 241); color: rgb(0, 0, 0)");

   sttng =  new QPushButton("SETTING", this);
   sttng ->setGeometry(MyData::pause_sttng_rec);
   sttng -> setFont(QFont("Purisa", 20, QFont::Bold,true));
   sttng ->setStyleSheet("background-color: rgb(2, 165, 241); color: rgb(0, 0, 0)");



}

MyPause::~MyPause() {
    delete background;
    delete(resume);
    delete(sttng);
    delete(exit);
}
