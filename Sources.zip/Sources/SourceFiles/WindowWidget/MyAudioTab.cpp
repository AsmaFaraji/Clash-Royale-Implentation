//
// Created by asma on 6/28/16.
//

#include <Sources/HeaderFiles/MyData.h>
#include <Sources/HeaderFiles/MyMainWindow.h>
#include "Sources/HeaderFiles/WindowWidget/MyAudioTab.h"
MyAudioTab::MyAudioTab(QWidget *parent, Qt::WindowFlags f):
        QWidget(parent, f)
{
   // setGeometry(0,250,1000,315);
    setBtn();
    setSlider();
    setLayout();
    show();

}


void MyAudioTab::setBtn() {
    sndState = new QPushButton("UnMute",this);
    sndState ->setGeometry(500 ,200 ,110, 48);
    sndState -> setStyleSheet("background-color: rgb(2, 165, 241); color: rgb(0, 0, 0)");
    sndState -> setFont(QFont("Purisa", 20, QFont::Bold,true));
    connect(sndState, SIGNAL(clicked()), this, SLOT(MuteBtnClicked()));

}

void MyAudioTab::setSlider() {
    sndVolum = new QSlider(Qt::Orientation::Horizontal, this);
    sndVolum ->setRange(0, 100);
    sndVolum ->setTickInterval(1);
    sndVolum ->setTickPosition(QSlider::TicksBelow);
    sndVolum -> setValue(50);
    connect(sndVolum, SIGNAL(valueChanged(int)), this, SLOT(changeSlider(int)));
    music = new QLabel("MUSIC",this);
    music -> setFont(QFont("Purisa", 20,QFont::Bold,true));
    music ->setStyleSheet("QLabel {color : rgb(2, 165, 241); }");




}
void MyAudioTab::MuteBtnClicked() {
    if(sndState->text() == "UnMute") {
        sndState->setText("Mute");
        MyMainWindow::sndMute = true;
    }
    else
    {
        sndState->setText("UnMute");
        MyMainWindow::sndMute = false;
    }
    emit soundChanged();
}
void MyAudioTab::changeSlider(int value) {
    MyMainWindow::sndVol = value;
    emit soundChanged();
}
void MyAudioTab:: setLayout() {
    layout = new QHBoxLayout(this);
    layout->addWidget(music);
    layout ->addWidget(sndVolum);
}


MyAudioTab::~MyAudioTab() {
    delete sndState;
    delete music;
    delete sndVolum;
    delete(layout);
}