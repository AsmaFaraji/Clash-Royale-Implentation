//
// Created by asma on 6/30/16.
//

#include <Sources/HeaderFiles/MyData.h>
#include <iostream>
#include "Sources/HeaderFiles/WindowWidget/MyCard.h"
int MyCard::cardNum = 0;
MyCard ::MyCard(QWidget *parent, Qt::WindowFlags f) {

    battle = new QPushButton("BATTLE",this);
    battle ->setGeometry(870 ,0 ,130, 48);
    battle -> setStyleSheet("background-color: rgb(2, 165, 241); color: rgb(0, 0, 0)");
    battle -> setFont(QFont("Purisa", 20, QFont::Bold,true));

    back = new QPushButton("BACK",this);
    back ->setGeometry(0 ,0 ,110, 48);
    back -> setStyleSheet("background-color: rgb(2, 165, 241); color: rgb(0, 0, 0)");
    back -> setFont(QFont("Purisa", 20,QFont::Bold, false ));

    cnstructQlabel();
    cnstructCheckBox();
    setPos();
    setGeometry(MyData::mymainwindow_rec);
    setStyleSheet("color: rgb(2, 165, 241)");

    show();



}

void MyCard::cnstructCheckBox() {


    checkbox = new QList<QCheckBox*>();
    for(int i = 0; i< 15 ;i ++)
    checkbox->push_back(new QCheckBox(MyData::card_name[i], this));


    for(int i = 0;i < 15 ;i ++) {
        connect(checkbox->at(i), SIGNAL(stateChanged(int)), this, SLOT(countCard()));
//        checkbox ->at(i) -> setFont("purisa", 5,)
    }

}
void MyCard::cnstructQlabel() {
    imgLabl = new QList<QLabel*>();
    for (int i = 0; i < 15; i++)
        imgLabl->push_back(new QLabel(this));

    for (int i = 0; i < 15; i++) {
        imgLabl->at(i)->setPixmap(MyData::card_add[i]);
        imgLabl->at(i)->setAttribute(Qt::WA_TranslucentBackground);
    }
}
 void MyCard ::setPos() {

     checkbox->at(0)->setGeometry(120, 50, checkbox->at(0)->sizeHint().width(), checkbox->at(0)->sizeHint().height());
     imgLabl->at(0)->setGeometry(checkbox->at(0)->x()/* + checkbox->at(0)->width()*/,
                                 checkbox->at(0)->y() + checkbox->at(0)->sizeHint().height() + 20, 75, 75);


     checkbox->at(5)->setGeometry(120, imgLabl->at(0)->y() + 60 + 75, checkbox->at(5)->sizeHint().width(),
                                  checkbox->at(5)->sizeHint().height());
     imgLabl->at(5)->setGeometry(120, checkbox->at(5)->y() + checkbox->at(5)->sizeHint().height() + 20, 75, 75);

     checkbox->at(10)->setGeometry(120, imgLabl->at(5)->y() + 60 + 75, checkbox->at(10)->sizeHint().width(),
                                   checkbox->at(10)->sizeHint().height());
     imgLabl->at(10)->setGeometry(120, checkbox->at(10)->y() + checkbox->at(10)->sizeHint().height() + 20, 75, 75);


     for (int i = 1; i < 5; i++) {
         checkbox->at(i)->setGeometry(checkbox->at(i - 1)->x() + checkbox->at(i - 1)->sizeHint().width() + 20,
                                      checkbox->at(0)->y(), checkbox->at(i)->sizeHint().width(), checkbox->at(i)->sizeHint().height());
         imgLabl->at(i)->setGeometry(checkbox->at(i)->x(), checkbox->at(0)->y() + checkbox->at(i)->sizeHint().height() + 20, 75,
                                     75);
     }

     for (int i = 6; i < 10; i++) {
         checkbox->at(i)->setGeometry(checkbox->at(i - 1)->x() + checkbox->at(i - 1)->sizeHint().width() + 20,
                                      checkbox->at(5)->y(), checkbox->at(i)->sizeHint().width(), checkbox->at(i)->sizeHint().height());
         imgLabl->at(i)->setGeometry(checkbox->at(i)->x(), checkbox->at(5)->y() + checkbox->at(i)->sizeHint().height() + 20, 75,
                                     75);
     }


     for (int i = 11; i < 15; i++) {
         checkbox->at(i)->setGeometry(checkbox->at(i - 1)->x() + checkbox->at(i - 1)->sizeHint().width() + 20,
                                      checkbox->at(10)->y(), checkbox->at(i)->sizeHint().width(), checkbox->at(i)->sizeHint().height());
         imgLabl->at(i)->setGeometry(checkbox->at(i)->x(), checkbox->at(10)->y() + checkbox->at(i)->sizeHint().height() + 20, 75,
                                     75);
     }

 }
void MyCard::countCard() {
    cardNum = 0;
    for(int i = 0; i< 15 ;i ++)
        if(checkbox -> at(i) -> isChecked())
            cardNum ++;

    //std :: cout << cardNum << std :: endl;

}
MyCard::~MyCard() {
    for(int i = 0 ;i < 15 ; i ++)
        delete(checkbox->at(i));
    delete(checkbox);
    delete(imgLabl);
    delete(back);
    delete(battle);
}




