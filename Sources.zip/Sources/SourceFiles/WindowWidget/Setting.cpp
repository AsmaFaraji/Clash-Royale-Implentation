//
// Created by asma on 6/28/16.
//

#include <Sources/HeaderFiles/WindowWidget/Setting.h>
#include <Sources/HeaderFiles/MyData.h>
#include <iostream>


Setting::Setting() {
    setGeometry(MyData::mymainwindow_rec);
    loadImage();
    setTab();
    back = new QPushButton("BACK",this);
    back ->setGeometry(0 ,0 ,110, 48);
    back -> setStyleSheet("background-color: rgb(2, 165, 241); color: rgb(0, 0, 0)");
    back -> setFont(QFont("Purisa", 20, QFont::Bold,true));
    show();
}
void Setting ::loadImage() {
    bckgrnd_img = new QLabel(this);
    bckgrnd_img -> setPixmap(QPixmap(MyData::bckgrnd_img_add).scaled(1000, 700));
    bckgrnd_img -> setAlignment(Qt::AlignCenter);
    bckgrnd_img -> setAttribute(Qt::WA_TranslucentBackground);
    bckgrnd_img -> setGeometry(MyData::bckgrnd_img_rec);
}
void Setting::setTab() {
    tabs = new QTabWidget(this);
    audioTab = new MyAudioTab(tabs);
    modeTab = new MyModeTab(tabs);
    tabs->setStyleSheet("QWidget {background-color: rgba(0, 0, 0, 60%);}");
    tabs ->setStyleSheet("QTabWidget,QTabWidget::pane,QTabBar { background: transparent; border: 0px;background-color: rgba(0, 0, 0, 60%); }");
    tabs->addTab(audioTab, "Audio");
    tabs -> addTab(modeTab, "Mode");
    tabs ->setGeometry(0,250,1000,350);
}
Setting::~Setting() {
    delete audioTab;
    delete(modeTab);
    delete tabs;
    delete(bckgrnd_img);
}
