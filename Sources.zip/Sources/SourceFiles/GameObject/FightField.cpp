
//
// Created by asma on 7/7/16.
//

#include "Sources/HeaderFiles/GameObject/FightField.h"
#include <QGraphicsSceneMouseEvent>
#include <QImage>
#include <Sources/HeaderFiles/GameObject/SingleMap.h>
#include <Sources/HeaderFiles/MyMainWindow.h>
#include <iostream>

FightField::FightField(QImage *img, const QRect & rect) {
    loadImage(img, rect);
}
void FightField::mousePressEvent(QGraphicsSceneMouseEvent *event) {
    MyMap *myMainMap;
    int index = MyMainWindow::pressedcard->getCharacter();

    CrCard *c = 0;
    if (MyMainWindow::myMainMap->getElixirBar()->value() >= MyMainWindow::pressedcard->getCost()) {
        if (index == 1) {
            c = (new IceWizard(1));
            c->loadImage(new QImage(MyData::card_add[0]), QRect((int) event->pos().x() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                (int) event->pos().y() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                60, 60));
        }
        else if (index == 2) {
            c = (new Witch(1));
            c->loadImage(new QImage(MyData::card_add[1]), QRect((int) event->pos().x() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                (int) event->pos().y() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                60, 60));
        }
        else if (index == 3) {
            c = (new Zap(1));
            c->loadImage(new QImage(MyData::card_add[2]), QRect((int) event->pos().x() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                (int) event->pos().y() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                60, 60));
        }
        else if (index == 4) {
            c = (new Rage(1));
            c->loadImage(new QImage(MyData::card_add[3]), QRect((int) event->pos().x() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                (int) event->pos().y() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                60, 60));
        }
        else if (index == 5) {
            c = (new InfernoTower(1));

            c->loadImage(new QImage(MyData::card_add[4]), QRect((int) event->pos().x() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                (int) event->pos().y() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                60, 60));
        }
        else if (index == 6) {
            c = (new Furnance(1));
            c->loadImage(new QImage(MyData::card_add[5]), QRect((int) event->pos().x() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                (int) event->pos().y() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                60, 60));
        }
        else if (index == 7) {
            c = (new LavaHound(1));
            c->loadImage(new QImage(MyData::card_add[6]), QRect((int) event->pos().x() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                (int) event->pos().y() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                60, 60));
        }
        else if (index == 8) {
            c = (new Miner(1));
            c->loadImage(new QImage(MyData::card_add[7]), QRect((int) event->pos().x() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                (int) event->pos().y() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                60, 60));

        }
        else if (index == 9) {
            c = (new Valkyrie(1));
            c->loadImage(new QImage(MyData::card_add[8]), QRect((int) event->pos().x() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                (int) event->pos().y() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                60, 60));

        }
        else if (index == 10) {
            c = (new CrCard(1));
            c->loadImage(new QImage(MyData::card_add[9]), QRect((int) event->pos().x() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                (int) event->pos().y() -
                                                                (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                60, 60));
        }
        else if (index == 11) {
            c = (new DarkPrince(1));
            c->loadImage(new QImage(MyData::card_add[10]), QRect((int) event->pos().x() -
                                                                 (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                 (int) event->pos().y() -
                                                                 (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                 60, 60));
        }
        else if (index == 12) {
            c = (new RoyalGianet(1));
            c->loadImage(new QImage(MyData::card_add[11]), QRect((int) event->pos().x() -
                                                                 (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                 (int) event->pos().y() -
                                                                 (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                 60, 60));
        }
        else if (index == 13) {
            c = (new Balloon(1));
            c->loadImage(new QImage(MyData::card_add[12]), QRect((int) event->pos().x() -
                                                                 (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                 (int) event->pos().y() -
                                                                 (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                 60, 60));
        }
        else if (index == 14) {
            c = (new HogRider(1));
            c->loadImage(new QImage(MyData::card_add[13]), QRect((int) event->pos().x() -
                                                                 (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                 (int) event->pos().y() -
                                                                 (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                 60, 60));
        }
        else if (index == 15) {
            c = (new Valkyrie(1));
            c->loadImage(new QImage(MyData::card_add[14]), QRect((int) event->pos().x() -
                                                                 (int) MyMainWindow::pressedcard->boundingRect().center().x(),
                                                                 (int) event->pos().y() -
                                                                 (int) MyMainWindow::pressedcard->boundingRect().center().y(),
                                                                 60, 60));
        }


        MyMainWindow::myMainMap->getElixirBar()->setValue(
                MyMainWindow::myMainMap->getElixirBar()->value() - MyMainWindow::pressedcard->getCost());


        if (MyMainWindow::pressedcard->getCharacter() != 0 && c) {
         //   std::cout << index << std::endl;
            MyMainWindow::myMainMap->getScene()->addItem(c);
            MyMainWindow::myObjects->push_back(c);
        }
        emit pressOnFightField();
    }
}
