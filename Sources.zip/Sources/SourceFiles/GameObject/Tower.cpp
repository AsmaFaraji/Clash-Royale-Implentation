//
// Created by asma on 7/3/16.
//

#include <Sources/HeaderFiles/MyData.h>
#include "Sources/HeaderFiles/GameObject/Tower.h"
#include <QGraphicsPixmapItem>
#include <iostream>
#include <Sources/HeaderFiles/MyMainWindow.h>
#include <Sources/HeaderFiles/GameObject/Cards/Weapon.h>
#include<QTimer>
#include "Sources/HeaderFiles/GameObject/CrObject.h"
Tower::Tower(MyData::HitPoint  hitPoint, MyData::HitSpeed  hitSpeed, MyData::Damage damage, MyData::Sight sight, MyData::Range range, MyData::Target target,
             MyData::Type type, QImage * img, const QRect &rect,int team):CrObject(hitPoint, hitSpeed, damage, sight, range, target, type,team){
    loadImage(img, rect);
   /// std :: cout <<" x: " << x() << " y: " << y() << std::endl;
   foundEnemy = false;
    enemy = 0;
    weapon = new QList<Weapon*>();
    attacktimer = new QTimer();
    attacktimer->start((int)(getHitSpeed() * 1000));
    lifetimer = new QTimer();
    lifetimer->start(50);
    connect(lifetimer, SIGNAL(timeout()), this, SLOT(die()));
    connect(attacktimer, SIGNAL(timeout()), this, SLOT(attack()));



}
void Tower::RangeChecker() {

}


void Tower::attack() {

    for(int i = 3 ;i < MyMainWindow::myObjects -> size() ; i ++ )
    {
        if(InRange(MyMainWindow::myObjects->at(i)) && InSight(MyMainWindow::myObjects->at(i))&& MyMainWindow::myObjects->at(i) != this&& MyMainWindow::myObjects->at(i)->isAlive() && MyMainWindow::myObjects->at(i)->getTeam() != getTeam()){
            enemy = MyMainWindow::myObjects -> at(i);
            weapon->push_back(new Weapon(false,x(),y(),enemy ->x() + enemy -> boundingRect().center().x(), enemy -> y() + enemy->boundingRect().center().y()));
            MyMainWindow::myMainMap -> getScene() -> addItem(weapon->last());

            enemy->setHintPoint(enemy -> getHitPoint() - getDamage());
           /// std::cout << "tower: " << getHitPoint() << std::endl;
        }
    }




}
bool Tower::InRange(CrObject* object) {
    double x1 = x() + boundingRect().center().x();
    double y1 = y() + boundingRect().center().y();

    double x2 = object->x() + object->boundingRect().center().x();
    double y2 = object->y() + object->boundingRect().center().y();

    return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) <= getRange() * getRange();
}
bool Tower::InSight(CrObject* object) {
    double x1 = x() + boundingRect().center().x();
    double y1 = y() + boundingRect().center().y();

    double x2 = object->x() + object->boundingRect().center().x();
    double y2 = object->y() + object->boundingRect().center().y();

    return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) <= getSight() * getSight();
}
void Tower::resumed() {
  //  std::cout << "i am towerrrrrrrrrrr" << std::endl;
    if(isAlive()) {
        attacktimer = new QTimer();
        attacktimer->start((int)(getHitSpeed() * 1000));
        lifetimer = new QTimer();
        lifetimer->start(50);
        connect(lifetimer, SIGNAL(timeout()), this, SLOT(die()));
        connect(attacktimer, SIGNAL(timeout()), this, SLOT(attack()));
        for (int  i = 0 ; i < weapon->size() ; i ++)
        {
            weapon->at(i)->resumed();
        }
    }
}
void Tower::paused() {
   // std::cout << "i am tower" << std::endl;
    if(isAlive()) {
        disconnect(lifetimer, SIGNAL(timeout()), this, SLOT(die()));
        disconnect(attacktimer, SIGNAL(timeout()), this, SLOT(attack()));
        lifetimer->stop();
      //  std::cout << "i am tower anad paused" << std::endl;
        attacktimer->stop();
        delete(lifetimer);
        delete(attacktimer);
        for (int  i = 0 ; i < weapon->size() ; i ++)
        {
            weapon->at(i)->paused();
        }
    }
//    rangetimer->stop;
}
void Tower::die() {
    if(getHitPoint() <= 0)
    {
        MyMainWindow::myMainMap -> getScene() -> removeItem(this);
        setLife(false);
        lifetimer->stop();
        attacktimer->stop();
    }

}
Tower::~Tower() {
    for(int i =  weapon->size() - 1 ; i >= 0 ; i ++) {
        delete (weapon->at(i));
        weapon->removeLast();
    }
    delete(weapon);
}