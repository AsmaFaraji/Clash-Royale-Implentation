//
// Created by asma on 7/7/16.
//

#include "Sources/HeaderFiles/GameObject/MyMap.h"
MyMap::MyMap() {
    scene = new QGraphicsScene();
}
QGraphicsScene*& MyMap::getScene() {
    return scene;
}
QProgressBar*& MyMap::getElixirBar() {
    return elixirbar;
}
QTimer*& MyMap::getElixirTimer() {
    return elixirtimer;
}
MyMap::~MyMap() {
    delete scene;
}