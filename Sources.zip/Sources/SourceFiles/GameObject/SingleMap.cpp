//
// Created by asma on 7/1/16.
//

#include "Sources/HeaderFiles/GameObject/SingleMap.h"
#include "Sources/HeaderFiles/GameObject/CrObject.h"
#include "Sources/HeaderFiles/GameObject/Tower.h"
#include <Sources/HeaderFiles/MyData.h>
#include<QGraphicsPixmapItem>
#include <QScrollBar>
#include <QTimer>
#include <Sources/HeaderFiles/MyMainWindow.h>


SingleMap::SingleMap() {

    setGeometry(MyData::gameWindow_rec);
    setBackgroundBrush(QColor(124, 252, 0));
    setSceneRect(MyData::gameWindow_rec);
    setAttribute(Qt::WA_TranslucentBackground);
    setAlignment(Qt::AlignCenter);
    getScene() -> setSceneRect(MyData::gameWindow_rec);
    setScene(getScene());
    setImage();
    verticalScrollBar() -> blockSignals(true);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    horizontalScrollBar()->blockSignals(true);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setInteractive(true);
    update();
    show();

}
void SingleMap::setImage() {

    fightfield = new FightField (new QImage(MyData::map_add[0]), QRect(0, 0, 1000, 640));
    getScene() -> addItem(fightfield);

    for(int i = 1 ;i < 4; i++) {
        QImage *img = new QImage(MyData::map_add[i]);
        QPixmap *pix = new QPixmap();
        item[i]= new QGraphicsPixmapItem();
        pix->convertFromImage(img->scaled(MyData::smapobject_size[i]));
        item[i]->setPixmap(*pix);
        item[i]->setPos(MyData::smapobject_point[i]);
        getScene()->addItem(item[i]);
        delete pix;
        delete img;

    }

    pause = new QPushButton("Pause");
    pause-> setFont(QFont("Purisa", 20, QFont::Bold,true));
    pause ->setStyleSheet("background-color: rgb(124, 252, 0); color: rgb(0, 0, 0)");
    pause->setGeometry(MyData::pausebtn_rec);
    getScene()->addWidget(pause);



    score = new QLabel("0");
    score-> setFont(QFont("Purisa", 20, QFont::Bold,true));
    score->setStyleSheet("QLabel{background:transparent;}");
    score -> setAlignment(Qt::AlignCenter);
    score->setGeometry(MyData::score_rec);
    getScene()->addWidget(score);



    myscore = new QLabel("0");
    myscore-> setFont(QFont("Purisa", 20, QFont::Bold,true));
    myscore->setStyleSheet("QLabel{background:transparent;}");
    myscore -> setAlignment(Qt::AlignCenter);
    myscore->setGeometry(MyData::myscore_rec);
    getScene()->addWidget(myscore);





}
void SingleMap::setFightFieldTower() {

    tower[0]= new Tower(2000, 0.8, 200, 8 * 30, 8 *30,MyData::All ,MyData::Building, new QImage(MyData::stower_add[0]), MyData::stower[0], 1);
    tower[1] = new Tower(3000, 0.8, 300, 10 * 30, 10 * 30, MyData::All, MyData::Building,  new QImage(MyData::stower_add[1]), MyData::stower[1], 1);
    tower[2]= new Tower(2000, 0.8, 200, 8 * 30, 8 *30, MyData::All ,MyData::Building,  new QImage(MyData::stower_add[2]), MyData::stower[2], 1);
    tower[3] = new  Tower(2000, 0.8, 200, 8 * 30, 8 *30,MyData::All ,MyData::Building, new QImage(MyData::stower_add[3]), MyData::stower[3], 2);
    tower[4]  = new Tower(3000, 0.8, 200, 10 * 30, 10 *30,MyData::All ,MyData::Building, new QImage(MyData::stower_add[4]), MyData::stower[4], 2);
    tower[5]  = new Tower(2000, 0.8, 200, 8 * 30, 8 *30,MyData::All ,MyData::Building, new QImage(MyData::stower_add[5]), MyData::stower[5], 2);

    for( int i = 0 ; i < 6 ; i ++ )
        getScene()->addItem(tower[i]);
    setBar();

    for(int i = 3 ; i < 6 ; i ++)
        MyMainWindow::myObjects -> push_back((CrObject*)tower[i]);

}
void SingleMap::removeFightFieldTower() {
    /*for (int i = 0; i < 6 ; ++i) {
        getScene() -> removeItem(tower[i]);
        delete tower[i];
    }*/
    disconnect(getElixirTimer(), SIGNAL(timeout()), this, SLOT(onTimeOut()));
    getElixirTimer()->stop();
    delete(getElixirBar());
    delete(getElixirTimer());

}
void SingleMap::setBar() {
    getElixirBar() = new QProgressBar();
    getScene() ->addWidget(getElixirBar());
    getElixirTimer() = new QTimer();
    getElixirBar()->setGeometry(MyData::exirbar_rec);
    getElixirBar()->setMinimum(0);
    getElixirBar()-> setMaximum(10);
    getElixirBar()-> setOrientation(Qt:: Horizontal);

    getElixirBar()-> show();
    getElixirBar()-> setStyleSheet("QProgressBar::chunk {\n"
                                         "        text-align: center;"
                                         "    background-color: #05B8CC;\n"
                                         "    width: 20px;\n"


                                         "}");
    connect(getElixirTimer(), SIGNAL(timeout()), this, SLOT(onTimeOut()));
    getElixirTimer()-> start(5000);

}

void SingleMap::onTimeOut() {
    int value = getElixirBar()-> value();
    getElixirBar()-> setValue(++ value);
}
SingleMap::~SingleMap() {
    delete(fightfield);
    delete pause;
    delete score;
    delete myscore;
}
