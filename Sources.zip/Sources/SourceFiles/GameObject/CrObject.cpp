//
// Created by asma on 7/3/16.
//

#include <Sources/HeaderFiles/MyData.h>
#include<QObject>
#include <iostream>
#include "Sources/HeaderFiles/GameObject/CrObject.h"
CrObject::CrObject(MyData::HitPoint  hitPoint, MyData::HitSpeed  hitSpeed, MyData:: Damage damage, MyData::Sight sight, MyData::Range range, MyData::Target target, MyData::Type type,int team)
{
    pix = new QPixmap();
    setHintPoint(hitPoint);
    setHintSpeed(hitSpeed);
    setDamage(damage);
    setSight(sight);
    setRange(range);
    setTarget(target);
    setType(type);
    setLife(true);
    setTeam(team);
}
void CrObject::setType(MyData::Type type) {
    this -> type = type;
}
void CrObject::setTarget(MyData::Target target) {
    this -> target = target;
}
void CrObject::setRange(MyData::Range range) {
    this -> range = range;
}
void CrObject::setSight(MyData::Sight sight) {
    this -> sight = sight;
}
void CrObject::setDamage(MyData::Damage damage) {
    this -> damge = damage;
}
void CrObject::setHintSpeed(MyData::HitSpeed hintSpeed) {
    this -> hitSpeed = hintSpeed;
}
void CrObject::setHintPoint(MyData::HitPoint hintPoint) {
    this -> hitpoint = hintPoint;
}
void CrObject::setLife(bool life) {
    this->life = life;
}
void CrObject::setTeam(int team) {
    this->team = team;
}
MyData::HitPoint CrObject::getHitPoint() {
    return hitpoint;
}
MyData::HitSpeed CrObject::getHitSpeed() {
    return hitSpeed;
}
MyData::Damage CrObject::getDamage() {
    return damge;
}
MyData::Sight CrObject::getSight() {
    return sight;
}
MyData::Range CrObject::getRange() {
    return range;
}
MyData::Target CrObject::getTarget() {
    return target;
}
MyData::Type CrObject::getType() {
    return type;
}
bool CrObject:: isAlive(){
        return life;
}
int CrObject::getTeam() {
    return  team;
}
void CrObject::loadImage(QImage * img, const QRect rect)  {

     pix->convertFromImage(img -> scaled(rect.width(),rect.height()));
    setPixmap(*pix);
    setPos(rect.x(), rect.y());

}
QPixmap*& CrObject::getPixmap() {
    return pix;
}
void CrObject::test() {
    QPixmap pixMap;
    QImage img("Resources/tower_img/arenatower.png");
    pixMap.convertFromImage(img.scaled(90, 60));
    setPixmap(pixMap);
    setPos(0, 0);

}
CrObject::~CrObject() {
    delete(pix);
}
