//
// Created by asma on 7/12/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/BoxCard.h"
#include <QObject>
#include <Sources/HeaderFiles/MyMainWindow.h>

BoxCard::BoxCard(QImage * pix, int n, int cost) {
    img = pix;
    this -> n = n;
    inBox = false;
    this -> cost = cost;
    this->pix = new QPixmap();

}

BoxCard::~BoxCard() {
    delete pix;
    delete img;
}
void BoxCard::appear(QPoint &point)  {
    pix->convertFromImage(img->scaled(60, 60));
    setPixmap(*pix);
    setPos(point);
    inBox = true;
}
void BoxCard::disappear() {
    pix->convertFromImage(img->scaled(0, 0));
    setPixmap(*pix);
    setPos(0, 0);
    inBox = false;
}
void BoxCard::mousePressEvent(QGraphicsSceneMouseEvent * event) {
    if (MyMainWindow::myMainMap->getElixirBar()->value() >= cost){

        pix->convertFromImage(img->scaled(70, 60));
    setPixmap(*pix);
    MyMainWindow::pressedcard = this;
}
}
int BoxCard::getCost() const {
    return cost;
}
int BoxCard::getCharacter() const {
    return n;
}
