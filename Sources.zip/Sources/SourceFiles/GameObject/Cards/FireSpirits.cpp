//
// Created by asma on 7/5/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/FireSpirits.h"
FireSpirits::FireSpirits(int team):CrCard(43, 0, 30, 3 * 30, 70, 1, 2, 3, MyData::VeryFast,MyData::TGround,MyData::Air_Ground,MyData::Troop,team) { }
