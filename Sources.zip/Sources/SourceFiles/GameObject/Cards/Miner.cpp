//
// Created by asma on 7/5/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/Miner.h"
Miner::Miner(int team):CrCard(1000, 1.2,160, 3 *30, 70, 1, 3, 1, MyData::Fast, MyData::TGround,MyData::Ground,MyData::Troop, team) { }






















