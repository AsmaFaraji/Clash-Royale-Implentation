//
// Created by asma on 7/5/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/Rage.h"
Rage::Rage(int team):CrCard(0,0, 0,0,0,0,3,0,MyData::Sp, MyData::FT,MyData::Ta,MyData::Spell,team) {
    setRadius(5);
    setDuration(8);
}

void Rage::setRadius(MyData::Range radius) {
    this->radius = radius;

}
void Rage::setDuration(MyData::Duration duration) {
    this ->duration = duration;
}
MyData::Radius Rage::getRadius() {
    return radius;
}
MyData::Duration Rage::getDuration() {
    return duration;
}



/*
    ObjectType = Consts::spell;
    Cost = 3;
    Radius = 5;
    Duration = 8;
}*/