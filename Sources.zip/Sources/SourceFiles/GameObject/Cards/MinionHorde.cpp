//
// Created by asma on 7/5/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/MinionHorde.h"
MinionHorde::MinionHorde(int team):CrCard(90, 1, 40, 3.5 * 30, 2.5 * 30, 1, 5, 6, MyData::Fast, MyData::TGround,MyData::Air_Ground, MyData::Troop, team) { }








