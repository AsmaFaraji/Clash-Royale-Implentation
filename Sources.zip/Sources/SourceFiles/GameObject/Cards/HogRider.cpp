//
// Created by asma on 7/5/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/HogRider.h"
HogRider::HogRider(int team):CrCard(800, 1.5, 150, 80, 70,1, 4, 1, MyData::VeryFast,MyData::TGround,MyData::Buildings,MyData::Troop,team ) { }






