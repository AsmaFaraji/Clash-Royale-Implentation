//
// Created by asma on 7/5/16.
//

#include <iostream>
#include "Sources/HeaderFiles/GameObject/Cards/Valkyrie.h"
#include <math.h>
Valkyrie::Valkyrie(int team):CrCard(880, 1.5, 120, 80, 70, 1, 4 ,1, MyData::Medium,MyData::TGround,MyData::Ground,MyData::Troop,team ) { }














