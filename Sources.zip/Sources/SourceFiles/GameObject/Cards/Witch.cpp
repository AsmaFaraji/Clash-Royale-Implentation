//
// Created by asma on 7/5/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/Witch.h"
Witch::Witch(int team):CrCard(500, 0.7,42, 6.5 * 30, 5.5 * 30,1, 5, 1, MyData::Medium, MyData::TGround,MyData::Air_Ground,MyData::Troop, team) { }










/* void Witch::setSpecifications()
{
    HitPoints = 500;
    HitSpeed =  0.7;
    Range = 5.5 * 35;
    Vision = 6.5 * 35;
    Damage = 42;
    ObjectType = Consts::troop;
    ObjectTargets = Consts::Air_Ground;

    Speed = Consts::Medium;
    DeployTime = 1;
    Cost = 5;
    Count = 1;
    ag = Consts::GroundTroop;
}*/