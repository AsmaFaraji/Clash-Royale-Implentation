//
// Created by asma on 7/5/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/DarkPrince.h"
DarkPrince::DarkPrince(int team) :CrCard(700,  1.5,200,  100, 70,1,4, 1, MyData::Medium,MyData::TGround,MyData::Ground,MyData::Troop, team){}