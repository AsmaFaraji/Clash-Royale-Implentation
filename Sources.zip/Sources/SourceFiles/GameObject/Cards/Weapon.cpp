//
// Created by asma on 7/15/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/Weapon.h"
#include <QTimer>
#include <Sources/HeaderFiles/MyMainWindow.h>


Weapon::Weapon(bool isFire, double bx, double by, double ex, double ey)  {
    this -> isFire = isFire;
    timer  = new QTimer();
    timer -> start(30);
    connect(timer, SIGNAL(timeout()),this, SLOT(burst()));
    beginX = bx;
    beginY = by;
    endX = ex;
    endY = ey;
    isAlive = true;
    if(this -> isFire)
        loadImage(new QImage("Resources/Cards/Fireball.png"), QRect(beginX, beginY, 10, 10));
    else
        loadImage(new QImage("Resources/Cards/arrow.png"), QRect(beginX, beginY, 20, 20));


}
void Weapon::burst() {
    if(x() == endX)
    {
        double dy = endY < y() ? -3 : 3;
        transfer(0,dy);
    }

    else
        if(y() == endY)
        {
            double dx = endX > x() ?3 : -3;
            transfer(dx, 0);
        }
     else
        {
            slope = (endY - y())/(endX - x());
            double dx = abs(4 * cos(atan(slope))) * (x()< endX ? 1 : -1);
            double dy = fabs(4 * sin(atan(slope))) * (y() < endY? 1 : -1);
            transfer(dx, dy);
        }


}
void Weapon::transfer(double dx, double dy) {

    if ((fabs(endX - x()) > 4 || fabs(endY - y()) > 4) && isAlive)
        setPos(x() + dx, y() + dy);
    else {
        timer->stop();
        isAlive = false;
        MyMainWindow::myMainMap->getScene()->removeItem(this);
    }

}
void Weapon::resumed() {
    if(isAlive) {
        timer  = new QTimer();
        timer -> start(30);
        connect(timer, SIGNAL(timeout()),this, SLOT(burst()));
    }
}
void Weapon::paused() {
    if(isAlive) {
        timer->stop();
        disconnect(timer, SIGNAL(timeout()), this, SLOT(burst()));
        delete (timer);
    }
}
Weapon::~Weapon() {

}