//
// Created by asma on 7/4/16.
//

#include <iostream>
#include <Sources/HeaderFiles/GameObject/Cards/CrCard.h>
#include <Sources/HeaderFiles/MyMainWindow.h>
#include <Sources/HeaderFiles/GameObject/Cards/Weapon.h>
#include "Sources/HeaderFiles/GameObject/Cards/CrCard.h"
#include <QTimer>
CrCard::CrCard(MyData::HitPoint  hitPoint, MyData::HitSpeed  hitSpeed, MyData::Damage damage, MyData::Sight sight, MyData::Range range,
               MyData::DeployTime deploytime, MyData::Cost cost,MyData::Count count, MyData::Speed speed,MyData::FightTerittory fightterittory, MyData::Target target,
                MyData::Type type, int team):CrObject(hitPoint, hitSpeed, damage, sight, range, target, type,team), fight(false) {

    foundEnemy = false;
    fight = false;
    stop = false;
    enemy = 0;
    starttimer = new QTimer();
    starttimer->start(1000);
    connect(starttimer, SIGNAL(timeout()), this, SLOT(go()));
    weapon = new QList<Weapon*>();


}

void CrCard::setDeployTime(MyData::DeployTime deployTime) {
    this -> deployTime = deployTime;
    //std::cout << deployTime << std :: endl;
}
void CrCard::setCount(MyData::Count count) {
    this -> count = count;
}
void CrCard::setCost(MyData::Cost cost) {
    this -> cost = cost;
}
void CrCard::setFightTerittory(MyData::FightTerittory  fightterittory) {
    this -> fightterittory = fightterittory;
}
void CrCard::setSpeed(MyData::Speed speed) {
    this->speed = speed;
}
MyData::DeployTime CrCard::getDeployTime() {
    return deployTime;
}
MyData::Cost CrCard::getCost() {
    return cost;
}
MyData::Count CrCard::getCout() {
    return count;
}
MyData::FightTerittory CrCard::getFightTerittory() {
    return fightterittory;
}
MyData::Speed CrCard::getSpeed() {
    return speed;
}
bool& CrCard::getFight() {
    return fight;
}
void CrCard::move() {

   // std::cout << "stop: "  << stop << std::endl;
    if(!stop) {
        moveToRiver();
        moveToTower();
    }





}
void CrCard::moveToRiver() {
        if((y() >= 275 && y() <= 700 )) {
            if ((x() >= 510 && x() <= 1000)) {
                ang = fabs(atan((325 - y()) / (760 - x())));
                ang = atan((325 - y()) / (760 - x()));
                dx = fabs(cos(ang)) * 5 * (x() > 760 ? -1 : 1);
                dy = -fabs(sin(ang)) * 5;
                transfer(dx, dy);
            }
            else if ((x() >= 0 && x() <= 510)) {
               // std::cout <<"x: " << x() << " "<<"y: " << y() << std::endl;
                ang = atan((335 - y()) / (230 - x()));
                dx = fabs(cos(ang)) * 5 * (x() > 230 ? -1 : 1);
                dy = -fabs(sin(ang)) * 5;
                transfer(dx, dy);

            }
        }
}
void CrCard::moveToTower() {
    if((y() >= 0 && y() <= 275 ))
        if((x() >= 510 && x() <=1000) && MyMainWindow::myObjects->at(2)->isAlive()) {
            ang = atan((90 - y()) / (760 - x()));
            dx = fabs(cos(ang)) * 5 * (x() > 760 ? -1 : 1);
            dy = -fabs(sin(ang)) * 5;
            transfer(dx, dy);

        }
    else
            if(x() >= 0 && x() <= 510 && MyMainWindow::myObjects->at(0)->isAlive())
            {
                ang = atan((90 - y()) / (240 - x()));
                dx = fabs(cos(ang)) * 5 * (x() > 240 ? -1 : 1);
                dy = -fabs(sin(ang)) * 5;
                transfer(dx, dy);


            }
    else
            {
                ang = atan((90 - y()) / (520 - x()));
                dx = fabs(cos(ang)) * 5 * (x() > 520 ? -1 : 1);
                dy = -fabs(sin(ang)) * 5;
                transfer(dx, dy);

            }

}
void CrCard::RangeChecker() {
    for(int i = 0 ; i< MyMainWindow::myObjects->size() && i< 3; i ++)
    {
        if(InRange(MyMainWindow::myObjects->at(i)) && MyMainWindow::myObjects->at(i)->isAlive())
          return;
        else
            stop = false;
    }

}
void CrCard::moveToEnemy() {

std::cout << enemy ->x() << std::endl;
    ang = atan((enemy ->y() - y()) / (enemy -> x() - x()));
    dx = fabs(cos(ang)) * 5 * (x() > enemy -> x() ? -1 : 1);
    dy = fabs(sin(ang)) * 5 * (y() > enemy -> y() ? -1 : 1);
    transfer(dx, dy);
}
void CrCard::attack() {

for(int i = 0 ; i < 3 && i < MyMainWindow::myObjects -> size() ; i ++ )
{
    if(InRange(MyMainWindow::myObjects->at(i)) && InSight(MyMainWindow::myObjects->at(i))&& MyMainWindow::myObjects->at(i) != this&& MyMainWindow::myObjects->at(i)->isAlive()){
        enemy = MyMainWindow::myObjects -> at(i);
        weapon->push_back(new Weapon(true,x(),y(),enemy ->x() + enemy -> boundingRect().center().x(), enemy -> y() + enemy->boundingRect().center().y()));
        MyMainWindow::myMainMap -> getScene() -> addItem(weapon->last());
        enemy->setHintPoint(enemy -> getHitPoint() - getDamage());
       /// std::cout << "valkyrie: " << getHitPoint() << std::endl;
        stop = true;
    }
}



}
bool CrCard::InRange(CrObject * object) {
    double x1 = x() + boundingRect().center().x();
    double y1 = y() + boundingRect().center().y();

    double x2 = object->x() + object->boundingRect().center().x();
    double y2 = object->y() + object->boundingRect().center().y();

    return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) <= getRange() * getRange();
}

bool CrCard::InSight(CrObject *object) {
    double x1 = x() + boundingRect().center().x();
    double y1 = y() + boundingRect().center().y();

    double x2 = object->x() + object->boundingRect().center().x();
    double y2 = object->y() + object->boundingRect().center().y();

    return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) <= getSight() * getSight();
}
void CrCard::go() {
    disconnect(starttimer, SIGNAL(timeout()), this, SLOT(go()));
    starttimer -> stop();
    delete(starttimer);
    movetimer = new QTimer();
    movetimer -> start(50);
    rangetimer = new QTimer();
    rangetimer-> start(50);
    attacktimer = new QTimer();
    attacktimer->start((int)(getHitSpeed() * 1000));
    lifetimer = new QTimer();
    lifetimer->start(50);
    connect(lifetimer, SIGNAL(timeout()), this, SLOT(die()));
    connect(movetimer, SIGNAL(timeout()), this, SLOT(move()));
    connect(rangetimer, SIGNAL(timeout()), this, SLOT(RangeChecker()));
    connect(attacktimer, SIGNAL(timeout()), this, SLOT(attack()));

}
void CrCard::resumed() {
    if(isAlive()) {
        movetimer = new QTimer();
        movetimer -> start(50);
        rangetimer = new QTimer();
        rangetimer-> start(50);
        attacktimer = new QTimer();
        attacktimer->start((int)(getHitSpeed() * 1000));
        lifetimer = new QTimer();
        lifetimer->start(50);
        connect(lifetimer, SIGNAL(timeout()), this, SLOT(die()));
        connect(movetimer, SIGNAL(timeout()), this, SLOT(move()));
        connect(rangetimer, SIGNAL(timeout()), this, SLOT(RangeChecker()));
        connect(attacktimer, SIGNAL(timeout()), this, SLOT(attack()));
        for (int  i = 0 ; i < weapon->size() ; i ++)
        {
            weapon->at(i)->resumed();
        }

    }
}
void CrCard::paused() {
    std::cout << "hayirrr" << std::endl;
    if(isAlive()) {
        disconnect(lifetimer, SIGNAL(timeout()), this, SLOT(die()));
        disconnect(movetimer, SIGNAL(timeout()), this, SLOT(move()));
        disconnect(rangetimer, SIGNAL(timeout()), this, SLOT(RangeChecker()));
        disconnect(attacktimer, SIGNAL(timeout()), this, SLOT(attack()));
        movetimer->stop();
        lifetimer->stop();
        attacktimer->stop();
        rangetimer->stop();
        delete(movetimer);
        delete(attacktimer);
        delete(rangetimer);
        delete(lifetimer);

        for (int  i = 0 ; i < weapon->size() ; i ++)
        {
            weapon->at(i)->paused();
        }
    }
}
double CrCard::PI() {
    return std::atan(1)*4;
}
void CrCard::transfer(double dx, double dy) {
    setPos(x() + dx, y() + dy);
}
void CrCard::die() {
    if(getHitPoint() <= 0)
    {
        MyMainWindow::myMainMap -> getScene() -> removeItem(this);
        setLife(false);
        lifetimer->stop();
        movetimer->stop();
        attacktimer->stop();
        rangetimer->stop();
    }
}
CrCard::~CrCard() {
    for(int i =  0 ; i < weapon->size() ; i ++)
        delete(weapon->at(i));
    delete(weapon);
}
