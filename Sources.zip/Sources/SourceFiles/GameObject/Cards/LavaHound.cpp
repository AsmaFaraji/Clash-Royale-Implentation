//
// Created by asma on 7/4/16.
//

#include <iostream>
#include <Sources/HeaderFiles/GameObject/Cards/LavaHound.h>

LavaHound::LavaHound(int team):CrCard(3000, 1.3, 45, 3 * 30, 2* 30,1,7,1,MyData::Slow,MyData::TGround,MyData::Buildings,MyData::Troop, team) {}