//
// Created by asma on 7/5/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/IceWizard.h"
IceWizard::IceWizard(int team):CrCard(700, 1.2, 63,7 * 30 ,6 * 30 ,1,3, 1, MyData::Medium,MyData::TGround,MyData::Air_Ground,MyData::Troop,team){}
