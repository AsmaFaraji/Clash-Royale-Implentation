//
// Created by asma on 7/5/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/InfernoTower.h"
InfernoTower::InfernoTower(int team):CrCard(800, 0.4,400, 7.5 * 30, 6.5 * 30,1 , 5, 1, MyData::ZERO, MyData::TGround,MyData::Air_Ground,MyData::Building, team) {
    setLifeTime(40);
}

void InfernoTower::setLifeTime(MyData::LifeTime lifetime) {
    this->lifetime = lifetime;
}
MyData::LifeTime InfernoTower::getLifeTime() {
    return lifetime;
}