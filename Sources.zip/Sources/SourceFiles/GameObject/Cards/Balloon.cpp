//
// Created by asma on 7/5/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/Balloon.h"
#include <QTimer>
#include <iostream>

Balloon::Balloon(int team):CrCard(1020,3,600,3 * 30,70 ,1,5,1,MyData::Medium, MyData::TAir,MyData::Buildings,MyData::Troop,team ) {

}
Balloon::~Balloon() {

}