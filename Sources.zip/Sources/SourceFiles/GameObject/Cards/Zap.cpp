//
// Created by asma on 7/5/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/Zap.h"
Zap::Zap(int team):CrCard(0, 0,80,0,0,0,2,0,MyData::Sp,MyData::FT,MyData::Ta,MyData::Spell, team) {
    setCrownDamage(32);
    setRadius(2.5);
}

void Zap::setRadius(MyData::Radius radius) {
    this->radius = radius;
}
void Zap::setCrownDamage(MyData::CrownDamage crowndamage) {
    this ->crowndamage = crowndamage;
}
MyData::Radius Zap::getRadius() {
    return  radius;
}
MyData::CrownDamage Zap::getCrownDamage() {
    return crowndamage;
}

/*void Zap::setSpecifications()
{
    ObjectType = Consts::spell;
    Cost = 2;
    Radius = 2.5;
    Damage = 80;
    CDamage = 32;
}*/