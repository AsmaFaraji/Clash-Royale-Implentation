//
// Created by asma on 7/5/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/Furnance.h"
Furnance::Furnance(int team) :CrCard(1536, 10, 0, 0, 0,1,4,1,MyData::ZERO,MyData::TGround,MyData::Buildings,MyData::Building,team ){
    setLifeTime(50);
}

MyData::LifeTime Furnance::getLifeTime() {
    return lifetime;
}
void Furnance::setLifeTime(MyData::LifeTime lifetime) {
    this->lifetime = lifetime;
}




