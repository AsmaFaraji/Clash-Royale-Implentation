//
// Created by asma on 7/5/16.
//

#include "Sources/HeaderFiles/GameObject/Cards/RoyalGianet.h"
RoyalGianet::RoyalGianet(int team):CrCard(1200, 1.5, 78, 7.5 * 30, 6.5 * 30, 1 , 6, 1, MyData::Slow, MyData::TGround, MyData::Buildings,MyData::Troop, team) { }





