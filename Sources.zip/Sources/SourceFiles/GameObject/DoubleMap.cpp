//
// Created by asma on 7/2/16.
//

#include <Sources/HeaderFiles/MyData.h>
#include<QGraphicsPixmapItem>
#include <QGraphicsScene>
#include <QScrollBar>
#include <QTimer>
#include <Sources/HeaderFiles/MyMainWindow.h>
#include "Sources/HeaderFiles/GameObject/DoubleMap.h"
DoubleMap::DoubleMap() {
    setGeometry(MyData::gameWindow_rec);
    setBackgroundBrush(QColor(124, 252, 0));
    setSceneRect(MyData::gameWindow_rec);
    setAttribute(Qt::WA_TranslucentBackground);
    setAlignment(Qt::AlignCenter);
    getScene() -> setSceneRect(MyData::gameWindow_rec);
    setScene(getScene());
    setImage();
    verticalScrollBar() -> blockSignals(true);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    horizontalScrollBar()->blockSignals(true);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setInteractive(true);
    update();
    show();
}

void DoubleMap::setImage() {


    fightfield = new FightField (new QImage(MyData::map_add[0]), QRect(0, 0, 1000, 640));
    getScene() -> addItem(fightfield);


    for(int i = 1 ;i < 6; i++) {
        QImage *img = new QImage(MyData::map_add[i]);
        QPixmap *pix = new QPixmap();
        QGraphicsPixmapItem *item = new QGraphicsPixmapItem();
        pix->convertFromImage(img->scaled(MyData::dmapobject_size[i]));
        item->setPixmap(*pix);
        item->setPos(MyData::dmapobject_point[i]);
        getScene()->addItem(item);

        delete pix;

        delete img;

    }
//    for(int i = 0 ; i < 10 ; i ++) {
//        tower[i] = new Tower(0, 0, 0, 0, 0,MyData::Ta, MyData::Ty, new QImage(MyData::dtower_add[i]), MyData::dtower[i]);
//        getScene()->addItem((QGraphicsPixmapItem *) tower[i]);
//    }

    pause = new QPushButton("Pause");
    pause -> setFont(QFont("Purisa", 20, QFont::Bold,true));
    pause -> setStyleSheet("background-color: rgb(124, 252, 0); color: rgb(0, 0, 0)");
    pause -> setGeometry(MyData::pausebtn_rec);
    getScene() -> addWidget(pause);



    score = new QLabel("0");
    score-> setFont(QFont("Purisa", 20, QFont::Bold,true));
    score->setStyleSheet("QLabel{background:transparent;}");
    score -> setAlignment(Qt::AlignCenter);
    score->setGeometry(MyData::score_rec);
    getScene()->addWidget(score);



    myscore = new QLabel("0");
    myscore-> setFont(QFont("Purisa", 20, QFont::Bold,true));
    myscore->setStyleSheet("QLabel{background:transparent;}");
    myscore -> setAlignment(Qt::AlignCenter);
    myscore->setGeometry(MyData::myscore_rec);
    getScene()->addWidget(myscore);

}
void DoubleMap::setFightFieldTower() {
    tower[0]= new Tower(400, 0.8, 200, 10 * 30, 10 *30,MyData::All ,MyData::Building, new QImage(MyData::dtower_add[0]), MyData::dtower[0], 1);
    tower[1]= new Tower(400, 0.8, 200, 10 * 30, 10 *30,MyData::All ,MyData::Building, new QImage(MyData::dtower_add[1]), MyData::dtower[1], 1);
    tower[2]= new Tower(8000, 0.8, 200, 10 * 30, 10 *30,MyData::All ,MyData::Building, new QImage(MyData::dtower_add[2]), MyData::dtower[2], 1);
    tower[3]= new Tower(400, 0.8, 200, 10 * 30, 10 *30,MyData::All ,MyData::Building, new QImage(MyData::dtower_add[3]), MyData::dtower[3], 1);
    tower[4]= new Tower(400, 0.8, 200, 10 * 30, 10 *30,MyData::All ,MyData::Building, new QImage(MyData::dtower_add[4]), MyData::dtower[4], 1);
    tower[5]= new Tower(400, 0.8, 200, 10 * 30, 10 *30,MyData::All ,MyData::Building, new QImage(MyData::dtower_add[5]), MyData::dtower[5], 2);
    tower[6]= new Tower(400, 0.8, 200, 10 * 30, 10 *30,MyData::All ,MyData::Building, new QImage(MyData::dtower_add[6]), MyData::dtower[6], 2);
    tower[7]= new Tower(8000, 0.8, 200, 10 * 30, 10 *30,MyData::All ,MyData::Building, new QImage(MyData::dtower_add[0]), MyData::dtower[7], 2);
    tower[8]= new Tower(400, 0.8, 200, 10 * 30, 10 *30,MyData::All ,MyData::Building, new QImage(MyData::dtower_add[8]), MyData::dtower[8], 2);
    tower[9]= new Tower(400, 0.8, 200, 10 * 30, 10 *30,MyData::All ,MyData::Building, new QImage(MyData::dtower_add[9]), MyData::dtower[9], 2);

    for(int i = 0 ; i < 10 ; i ++ )
        getScene() -> addItem(tower[i]);


    setBar();

    for(int i = 5 ; i < 10 ; i ++)
        MyMainWindow::myObjects -> push_back((CrObject*)tower[i]);

}
void DoubleMap::removeFightFieldTower() {
    disconnect(getElixirTimer(), SIGNAL(timeout()), this, SLOT(onTimeOut()));
    getElixirTimer()->stop();
    delete(getElixirTimer());
    delete(getElixirTimer());
}
void DoubleMap::setBar() {
    getElixirBar()= new QProgressBar();
    getScene() ->addWidget(getElixirBar());
    getElixirTimer() = new QTimer();
    getElixirBar()->setGeometry(MyData::exirbar_rec);
    getElixirBar()->setMinimum(0);
    getElixirBar()-> setMaximum(10);
    getElixirBar()-> setOrientation(Qt:: Horizontal);

    getElixirBar()-> show();
    getElixirBar()-> setStyleSheet("QProgressBar::chunk {\n"
                                      "        text-align: center;"
                                      "    background-color: #05B8CC;\n"
                                      "    width: 20px;\n"


                                      "}");
    connect(getElixirTimer(), SIGNAL(timeout()), this, SLOT(onTimeOut()));
    getElixirTimer()-> start(5000);

}
void DoubleMap::onTimeOut() {
    int value = getElixirBar()-> value();
    getElixirBar()-> setValue(++ value);
}
DoubleMap::~DoubleMap() {
    delete(fightfield);
    delete pause;
    delete score;
    delete myscore;
}