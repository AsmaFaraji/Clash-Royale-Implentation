//
// Created by asma on 6/27/16.
//

#include <Sources/HeaderFiles/MyData.h>
#include <QtCore/qfileinfo.h>
#include <iostream>
#include <QtMultimedia/qmediaplaylist.h>
#include "Sources/HeaderFiles/MyMainWindow.h"
#include <string.h>
MyMainWindow::MyMainWindow() {
    setGeometry(MyData::mymainwindow_rec);
    setStack();
    setConnections();
    adjustMedia();
    setCentralWidget(stack);
    show();
    myboxcard = new QList<BoxCard*>();
    myMainMap = (MyMap*)snglemap;
    pressedcard = new BoxCard(new QImage(MyData::card_add[0]), 0);
    myObjects  = new QList<CrObject*>();

}

void MyMainWindow::loadImage() {
    bckgrnd_img = new QLabel(this);
    bckgrnd_img -> setPixmap(QPixmap(MyData::bckgrnd_img_add). scaled(1000, 700));
    bckgrnd_img -> setAlignment(Qt::AlignCenter);
    bckgrnd_img -> setAttribute(Qt::WA_TranslucentBackground);
    bckgrnd_img -> setGeometry(MyData::bckgrnd_img_rec);
}
void MyMainWindow ::setStack() {
    stack = new QStackedWidget(this);
    menu = new MyMenu();
    sttng = new Setting();
    mycard = new MyCard();
    mypause = new MyPause();
    snglemap = new SingleMap();
    dblemap = new DoubleMap();
    stack -> addWidget(menu);
    stack -> addWidget(sttng);
    stack -> addWidget(mycard);
    stack -> addWidget(mypause);
    stack -> addWidget(snglemap);
    stack -> addWidget(dblemap);

}
void MyMainWindow::adjustMedia() {
playlist = new QMediaPlaylist(this);
playlist->addMedia(QUrl :: fromLocalFile(QFileInfo(MyData::music_add).absoluteFilePath()));
playlist ->setPlaybackMode(QMediaPlaylist:: Loop);
mediaPlayer = new QMediaPlayer(this);
mediaPlayer ->setPlaylist(playlist);
mediaPlayer -> setMuted(false);
mediaPlayer -> setVolume(50);
mediaPlayer -> play();

}
void MyMainWindow::sttngBtnClicked() {
    stack -> setCurrentWidget(sttng);
}
void MyMainWindow::backBtnClicked() {
    stack -> setCurrentWidget(menu);
}
void MyMainWindow::battleBtnClicked() {
    mapcard_point[0] = QPoint(20, 640);
    mapcard_point[1] = QPoint(90, 640);
    mapcard_point[2] = QPoint(160, 640);
    mapcard_point[3] = QPoint(230, 640);
    for(int i = 4 ; i < 8 ; i ++)
        mapcard_point[i] = QPoint(0, 0);
    if(MyCard::cardNum == 8) {
        if (myMainMap == snglemap)
            dynamic_cast<SingleMap *>(myMainMap)->setFightFieldTower();
        else
           dynamic_cast<DoubleMap *>(myMainMap)->setFightFieldTower();

        setTimer();


        for(int i  = 0 ; i < 15 ; i ++)
            if(mycard ->checkbox -> at(i) -> isChecked() )
                myboxcard -> push_back(new BoxCard(new QImage(MyData::card_add[i]), i + 1,card_cost[i]));

        for(int i = 0 ; i < 4 ; i ++) {
            myboxcard->at(i)->appear(mapcard_point[i]);
            myMainMap -> getScene() ->addItem(myboxcard -> at(i));
        }

        stack->setCurrentWidget(myMainMap);


    }
}
void MyMainWindow::quitBtnClicked() {
    if(myMainMap == snglemap)
        dynamic_cast<SingleMap *>(myMainMap) -> removeFightFieldTower();
    else
        dynamic_cast<DoubleMap *>(myMainMap) -> removeFightFieldTower();



 /*   for(int i = 0 ;i < myObjects->size() ; i ++)
    {
        if(myObjects->at(i)->isAlive())
         myMainMap->getScene()->removeItem(myObjects->at(i));
//        if(dynamic_cast<CrCard*>(myObjects->at(i)))
//            for(int j = 0 ;j < dynamic_cast<CrCard*>(myObjects->at(i))->weapon->size() ; j ++ )
//            {
//                if(dynamic_cast<CrCard*>(myObjects->at(i))->weapon->at(j)->isAlive)
//                    myMainMap->getScene()->removeItem(dynamic_cast<CrCard*>(myObjects->at(i))->weapon->at(j));
//                delete(dynamic_cast<CrCard*>(myObjects->at(i))->weapon->at(j));
//                dynamic_cast<CrCard*>(myObjects->at(i))->weapon->removeLast();
//
//            }
//        else
//            if(dynamic_cast<Tower*>(myObjects->at(i)))
//                for (int  j = 0 ;j < dynamic_cast<CrCard*>(myObjects->at(i))->weapon->size() ;j ++)
//                {
//                    if(dynamic_cast<Tower*>(myObjects->at(i))->weapon->at(j)->isAlive)
//                        myMainMap->getScene()->removeItem(dynamic_cast<Tower*>(myObjects->at(i))->weapon->at(j));
//                    delete(dynamic_cast<Tower*>(myObjects->at(i))->weapon->at(j));
//                    dynamic_cast<Tower*>(myObjects->at(i))->weapon->removeLast();
//                }
        delete (myObjects->at(i));
       myObjects->removeLast();
    }
    for(int i = 0 ;i < myboxcard->size(); i ++){
        if(mapcard_point[i] != QPoint(0, 0))
            myMainMap->getScene()->removeItem(myboxcard->at(i));
        delete(myboxcard->at(i));
        myboxcard->removeLast();
    }
    disconnect(maintimer, SIGNAL(timeout()), this, SLOT(changeTime()));
    maintimer->stop();
    delete(maintimer);
    delete(timelabel);*/
    stack->setCurrentWidget(menu);
}
void MyMainWindow::resumeBtnClicked() {
    resumeMusic();

    for (int i = 0 ; i < myObjects->size() ; i ++) {
        if (dynamic_cast<Tower *>(myObjects->at(i)))
            dynamic_cast<Tower *>(myObjects->at(i))->resumed();
        else
            dynamic_cast<CrCard *>(myObjects->at(i))->resumed();
    }
    if(sttng -> modeTab -> sngl -> isChecked())
        stack -> setCurrentWidget(snglemap);

    else
        stack -> setCurrentWidget(dblemap);

    maintimer->start();
    myMainMap->getElixirTimer()->start();


}
void MyMainWindow::startBtnClicked() {
    stack -> setCurrentWidget(mycard);
}
void MyMainWindow::pauseBtnClicked() {
    pauseMusic();
    for (int i = 0 ; i < myObjects->size() ; i ++) {
        if (dynamic_cast<Tower *>(myObjects->at(i)))
                dynamic_cast<Tower *>(myObjects->at(i))->paused();
        else
            dynamic_cast<CrCard *>(myObjects->at(i))->paused();
    }
   // disconnect(maintimer, SIGNAL(timeout()), this, SLOT(changeTime()));
    maintimer->stop();
    myMainMap->getElixirTimer()->stop();
    stack -> setCurrentWidget(mypause);
}
void MyMainWindow::exitBtnClicked() {
    close();
}
void MyMainWindow::gameModeChanged() {
    myMainMap = sttng -> modeTab -> dble -> isChecked() ? (MyMap *) dblemap : (MyMap *) snglemap;
}
void MyMainWindow::setConnections() {
connect(menu ->setting, SIGNAL(clicked()),this, SLOT(sttngBtnClicked()));
connect(menu->choseCard, SIGNAL(clicked()), this, SLOT(startBtnClicked()));
connect(menu->exit,SIGNAL(clicked()), this, SLOT(exitBtnClicked()));
connect(sttng -> back,SIGNAL(clicked()), this, SLOT(backBtnClicked())) ;
connect(mycard -> battle, SIGNAL(clicked()), this, SLOT(battleBtnClicked()));
connect(mypause -> exit, SIGNAL(clicked()),this, SLOT(quitBtnClicked()));
connect(mypause -> resume,SIGNAL(clicked()), this,SLOT(resumeBtnClicked()));
connect(mypause ->sttng, SIGNAL(clicked()), this, SLOT(sttngBtnClicked()));
connect(menu -> start, SIGNAL(clicked()), this, SLOT(startBtnClicked()));
connect(sttng -> modeTab -> dble, SIGNAL(clicked()),this, SLOT(gameModeChanged()));
connect(sttng -> modeTab -> sngl, SIGNAL(clicked()),this, SLOT(gameModeChanged()));
connect(sttng->audioTab, SIGNAL(soundChanged()), this, SLOT(reAdjustMedia()));
connect(mycard->back, SIGNAL(clicked()),this, SLOT(backBtnClicked()));
connect(snglemap -> pause ,SIGNAL(clicked()), this, SLOT(pauseBtnClicked()));
connect(dblemap -> pause ,SIGNAL(clicked()), this, SLOT(pauseBtnClicked()));
connect(snglemap -> fightfield,SIGNAL(pressOnFightField()), this, SLOT(switchCards()));
connect(dblemap -> fightfield,SIGNAL(pressOnFightField()), this, SLOT(switchCards()));

}
void MyMainWindow::switchCards() {
    if(pressedcard -> getCharacter() != 0) {
        int index = myboxcard->indexOf(pressedcard, 0);
        myMainMap->getScene()->removeItem(pressedcard);
        QPoint temp = mapcard_point[index];
        mapcard_point[index] = QPoint(0, 0);
        pressedcard->disappear();
        if(index == 7)
            index = -1;
        while (myboxcard->at(++index)->inBox)
            if (index == 7)
                index = 0;

        myboxcard->at(index)->appear(temp);
        myMainMap->getScene()->addItem(myboxcard->at(index));
        mapcard_point[index] = temp;
    }

}
void MyMainWindow::setTimer() {

    min = 3;
    sec1 = 0;
    sec2 = 0;
    timelabel = new QLabel("3:00");
    timelabel -> setFont(QFont("Purisa", 20, QFont::Bold,true));
    timelabel -> setStyleSheet("QLabel{background:transparent;}");
    timelabel -> setGeometry(400, 650, 100, 48);
    myMainMap ->getScene() ->addWidget(timelabel);
    maintimer = new QTimer();
    maintimer -> start(1000);
    connect(maintimer, SIGNAL(timeout()), this, SLOT(changeTime()));

}
void MyMainWindow::changeTime() {
    if(timelabel->text() == "3:00"){
        timelabel->setText("2:59");
        min = 2;
        sec1 = 5;
        sec2 = 9;
    }
    else
        if(timelabel->text() == "2:00"){
        timelabel->setText("1:59");
        min = 1;
        sec1 = 5;
        sec2 = 9;
    }
    else
        if(timelabel->text() == "1:00") {
            timelabel->setText("0:59");
            min = 0;
            sec1 = 5;
            sec2 = 9;
        }
    else
         if(timelabel -> text() == "0:00")
         {
             quitBtnClicked();
         }
    else
        if(sec2 == 0) {
        sec2 = 9;
        sec1 -= 1;
        QString t = QString::fromUtf8((std::to_string(min) + ":" +std::to_string( sec1)  + std::to_string(sec2)).c_str());
        timelabel->setText(t);
    }
    else {
            sec2 -= 1;
            QString t = QString::fromUtf8((std::to_string(min) + ":" +std::to_string( sec1)  + std::to_string(sec2)).c_str());
            timelabel->setText(t);

        }

}
void MyMainWindow::reAdjustMedia() {
    mediaPlayer -> setMuted(sndMute);
    mediaPlayer -> setVolume(sndVol);
}
void MyMainWindow::pauseMusic() {
    mediaPlayer->pause();
}
void MyMainWindow::resumeMusic() {
    mediaPlayer->play();
}
BoxCard* MyMainWindow::pressedcard = 0;
MyMap* MyMainWindow::myMainMap = 0;
QList<CrObject*>* MyMainWindow::myObjects = 0;
int MyMainWindow::sndVol = 50;
bool MyMainWindow::sndMute = false;
 MyMainWindow::~MyMainWindow() {
     for(int i = 0 ;i < 8 ;i ++) {
         delete(myboxcard->at(i));
         myboxcard->removeLast();
     }
     delete(myboxcard);
     delete bckgrnd_img;
     delete sttng;
     delete(myFighters);
     delete myMainMap;
     delete(snglemap);
     delete(dblemap);
     delete(mycard);
     delete(mypause);
     delete(menu);
     delete(mediaPlayer);
     delete(playlist);
     delete(stack);
     delete(timelabel);
     delete(maintimer);
}