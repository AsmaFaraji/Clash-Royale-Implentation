//
// Created by asma on 6/27/16.
//

#ifndef CLASHROYALE_CONSTANTS_H
#define CLASHROYALE_CONSTANTS_H

#include<QtCore/qsize.h>
#include <QtCore/qrect.h>
#include <QtCore/qstring.h>
#include <Sources/HeaderFiles/GameObject/MyMap.h>

namespace MyData {


    typedef double HitPoint;
    typedef double HitSpeed;
    typedef double Damage;
    typedef double Sight;
    typedef double Range;
    typedef int DeployTime;
    typedef double Cost;
    typedef int Count;
    typedef int LifeTime;
    typedef double Radius;
    typedef int CrownDamage;
    typedef double Duration;


    enum Type {
        Ty, Building, Troop, Spell
    };
    enum Target {
        Ta, Buildings, Air, Ground, Air_Ground, All, NONE
    };
    enum Speed {
        Sp, Slow, Medium, Fast, VeryFast, ZERO
    };
    enum FightTerittory {
        FT, TAir, TGround
    };
    const QRect rect(0, 0, 0, 0);

    ///change the size of welcome page and the image of it;
    const QRect wlcm_img(0, 0, 1000, 587);
    const QRect bckgrnd_img_rec(0, 0, 1000, 700);
    const QRect mymainwindow_rec(0, 0, 1000, 700);
    const QRect startbtn_rec(885, 120, 115, 48);
    const QRect chosecardbtn_rec(885, 180, 115, 48);
    const QRect settngbtn_rec(885, 240, 115, 48);
    const QRect aboutbtn_rec(885, 300, 115, 48);
    const QRect exitbtn_rec(885, 360, 115, 48);
    const QRect namelbl_rec(780, 65, 60, 60);
    const QRect namelnedit_rec(850, 80, 150, 30);
    const QRect gameWindow_rec(0, 0, 1000, 700);
    const QRect pausebtn_rec(885, 650, 110, 48);
    const QRect score_rec(950, 0, 50, 50);
    const QRect myscore_rec(950, 550, 50, 50);
    const QRect resume_rec(200, 250, 150, 60);
    const QRect quit_rec(300, 360, 150, 60);
    const QRect pause_sttng_rec(380, 250, 150, 60);
    const QRect exirbar_rec(620, 650, 200, 30);
    const QRect stower[6] = {QRect(220, 540, 80, 80), QRect(480, 560, 80, 80),
                             QRect(750, 540, 80, 80), QRect(220, 10, 80, 80), QRect(480, 0, 80, 80),
                             QRect(750, 10, 80, 80)};
    const QRect dtower[10] = {QRect(90, 540, 80, 80), QRect(280, 540, 80, 80), QRect(450, 560, 80, 80),
                              QRect(645, 540, 80, 80), QRect(855, 540, 80, 80), QRect(90, 10, 80, 80),
                              QRect(280, 10, 80, 80), QRect(450, 0, 80, 80), QRect(645, 10, 80, 80),
                              QRect(855, 10, 80, 80)};



    ///tol arz
    const QSize smapobject_size[4] = {QSize(1000, 640), QSize(1000, 40), QSize(140, 60), QSize(140, 60)};
    const QPoint smapobject_point[4] = {QPoint(0, 0), QPoint(0, 285), QPoint(180, 275), QPoint(710, 275)};
    const QSize dmapobject_size[6] = {QSize(1000, 640), QSize(1000, 40), QSize(140, 60), QSize(140, 60),
                                      QSize(140, 60), QSize(140, 60)};
    const QPoint dmapobject_point[6] = {QPoint(0, 0), QPoint(0, 285), QPoint(20, 275), QPoint(210, 275),
                                        QPoint(570, 275), QPoint(780, 275)};




    //addresses
    extern const QString wlcm_img_add;
    extern const QString bckgrnd_img_add;
    extern const QString sttng_img_add;
    extern const QString ext_img_add;
    extern const QString strt_img_add;
    extern const QString help_img_add;
    extern const QString choseCard_img_add;
    extern const QString music_add;
    extern const QString card_add[15];
    extern const QString map_add[6];
    extern const QString pause_bckgrnd_img_add;
    extern const QString stower_add[6];
    extern const QString dtower_add[10];
//card data
    extern const QString card_name[15];



};

#endif //CLASHROYALE_CONSTANTS_H
