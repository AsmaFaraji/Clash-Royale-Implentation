//
// Created by asma on 6/29/16.
//

#ifndef CLASHROYALE_MYMODETAB_H
#define CLASHROYALE_MYMODETAB_H


#include <QtCore/qobjectdefs.h>
#include <QtWidgets/qwidget.h>
#include <QtWidgets/qradiobutton.h>
#include <QtWidgets/qboxlayout.h>
#include <QtWidgets/qgroupbox.h>
#include <QtWidgets/qlabel.h>

class MyModeTab:public QWidget {
    Q_OBJECT
    friend class Setting;
    friend class MyMainWindow;

public:
    MyModeTab(QWidget * = 0, Qt::WindowFlags = 0);
    ~MyModeTab();

private:
    QLabel *gmeMode;
    QRadioButton *sngl;
    QRadioButton *dble; ;
    QVBoxLayout *layout;
    QGroupBox *group;

    void setRadiobtn();
    void setLayout();

};


#endif //CLASHROYALE_MYMODETAB_H
