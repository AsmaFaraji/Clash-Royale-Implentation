//
// Created by asma on 6/30/16.
//

#ifndef CLASHROYALE_MYCARD_H
#define CLASHROYALE_MYCARD_H


#include <QtWidgets/qwidget.h>
#include <QtWidgets/qcheckbox.h>
#include <QtWidgets/qlabel.h>
#include <QtWidgets/qpushbutton.h>

class MyCard : public QWidget {
    Q_OBJECT
friend class MyMainWindow;
public:
    MyCard(QWidget * = 0, Qt::WindowFlags = 0);
    ~MyCard();
    QList<QCheckBox*> *checkbox;
    static int cardNum;

private slots:
    void countCard();

private:

    QList<QLabel *> *imgLabl;
    QPushButton *back;
    QPushButton *battle;
    void cnstructCheckBox();
    void cnstructQlabel();
    void setPos();




};


#endif //CLASHROYALE_MYCARD_H
