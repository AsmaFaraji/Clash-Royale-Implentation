//
// Created by asma on 6/28/16.
//

#ifndef CLASHROYALE_MYMENU_H
#define CLASHROYALE_MYMENU_H


#include <QtWidgets/qwidget.h>
#include <QtWidgets/qlabel.h>
#include <QtWidgets/qpushbutton.h>
#include <QtWidgets/qlineedit.h>

class MyMenu : public QWidget{
    friend class MyMainWindow;
    Q_OBJECT
public:
    MyMenu();
    ~MyMenu();
    void load_image();
    void setBtn();
    void setLinEdit();


private:
    QLabel *bckgrnd_img1;
    QLabel *name;
    QPushButton *start;
    QPushButton *exit;
    QPushButton *setting;
    QPushButton *about;
    QPushButton *choseCard;
    QLineEdit *myName;


};


#endif //CLASHROYALE_MYMENU_H
