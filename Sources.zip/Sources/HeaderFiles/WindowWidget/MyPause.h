//
// Created by asma on 7/2/16.
//

#ifndef CLASHROYALE_MYPAUSE_H
#define CLASHROYALE_MYPAUSE_H


#include <QtWidgets/qwidget.h>
#include <QLabel>
#include <QtWidgets/qpushbutton.h>

class MyPause: public QWidget {
    Q_OBJECT
friend class MyMainWindow;
public:
    MyPause();
    ~MyPause();

private:
    QLabel *background;
    QPushButton *resume;
    QPushButton *exit;
    QPushButton *sttng;

    void setBtn();
    void loadImage();


};


#endif //CLASHROYALE_MYPAUSE_H
