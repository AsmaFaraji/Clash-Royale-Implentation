//
// Created by asma on 6/28/16.
//

#ifndef CLASHROYALE_SETTING_H
#define CLASHROYALE_SETTING_H


#include <QtWidgets/qwidget.h>
#include <QtWidgets/qtabwidget.h>
#include "MyAudioTab.h"
#include "MyModeTab.h"

class Setting: public QWidget {
    Q_OBJECT
friend class MyMainWindow;
public:
    Setting();
    ~Setting();


// signals:
//    void settingChanged();

// private slots:
 //void changeSndState();

private:
MyAudioTab *audioTab;
MyModeTab *modeTab;
QTabWidget *tabs;
QLabel *bckgrnd_img;
QPushButton *back;
void loadImage();
void setTab();







};


#endif //CLASHROYALE_SETTING_H
