//
// Created by asma on 6/28/16.
//

#ifndef CLASHROYALE_MYAUDIOTAB_H
#define CLASHROYALE_MYAUDIOTAB_H


#include <QtWidgets/qwidget.h>
#include <QtWidgets/qpushbutton.h>
#include <QtWidgets/qslider.h>
#include <QtWidgets/qlabel.h>
#include <QtWidgets/qboxlayout.h>

class MyAudioTab : public QWidget{
    Q_OBJECT
    friend class Setting;

public:
    MyAudioTab(QWidget * = 0, Qt::WindowFlags = 0);
    ~MyAudioTab();
    void setBtn();
    void setSlider();
    void setLayout();

    private slots:
     void MuteBtnClicked();
     void changeSlider(int);

    signals:
    void soundChanged();

private:
    QHBoxLayout *layout;
    QPushButton *sndState;
    QLabel *music;
    QSlider *sndVolum;


};


#endif //CLASHROYALE_MYAUDIOTAB_H
