//
// Created by asma on 6/26/16.
//

#ifndef CLASHROYALE_MYWELCOMWINDOW_H
#define CLASHROYALE_MYWELCOMWINDOW_H


#include <QtWidgets/qwidget.h>
#include <QtWidgets/qprogressbar.h>
#include <QtCore/qtimer.h>
#include <QLabel>
#include <QtWidgets/qmainwindow.h>

class MyWelcomWindow  : QMainWindow{

    Q_OBJECT
public:
    MyWelcomWindow();
    void loadImage();
    void setQprogressBar();
    void setLayout();

private slots:
    void onTimeOut();

private:
    QProgressBar *progressbar;
    QTimer *timer;
    QLabel *wlcomImage;




};


#endif //CLASHROYALE_MYWELCOMWINDOW_H
