//
// Created by asma on 6/27/16.
//

#ifndef CLASHROYALE_MYMAINWINDOW_H
#define CLASHROYALE_MYMAINWINDOW_H


#include <QtWidgets/qpushbutton.h>
#include <QtWidgets/qlabel.h>
#include <QtWidgets/qstackedwidget.h>
#include <QtWidgets/qmainwindow.h>
#include <Sources/HeaderFiles/WindowWidget/MyMenu.h>
#include <Sources/HeaderFiles/WindowWidget/Setting.h>
#include <QtMultimedia/qmediaplayer.h>
#include <Sources/HeaderFiles/WindowWidget/MyCard.h>
#include <Sources/HeaderFiles/WindowWidget/MyPause.h>
#include <Sources/HeaderFiles/GameObject/SingleMap.h>
#include <Sources/HeaderFiles/GameObject/DoubleMap.h>
#include <Sources/HeaderFiles/GameObject/Cards/IceWizard.h>
#include <Sources/HeaderFiles/GameObject/Cards/Witch.h>
#include <Sources/HeaderFiles/GameObject/Cards/Zap.h>
#include <Sources/HeaderFiles/GameObject/Cards/Rage.h>
#include <Sources/HeaderFiles/GameObject/Cards/InfernoTower.h>
#include <Sources/HeaderFiles/GameObject/Cards/Furnance.h>
#include <Sources/HeaderFiles/GameObject/Cards/LavaHound.h>
#include <Sources/HeaderFiles/GameObject/Cards/Miner.h>
#include <Sources/HeaderFiles/GameObject/Cards/Valkyrie.h>
#include <Sources/HeaderFiles/GameObject/Cards/DarkPrince.h>
#include <Sources/HeaderFiles/GameObject/Cards/RoyalGianet.h>
#include <Sources/HeaderFiles/GameObject/Cards/Balloon.h>
#include <Sources/HeaderFiles/GameObject/Cards/HogRider.h>
#include <Sources/HeaderFiles/GameObject/Cards/MinionHorde.h>
#include <Sources/HeaderFiles/GameObject/Cards/BoxCard.h>

class MyMainWindow  : QMainWindow{
    Q_OBJECT
public:
    MyMainWindow();
    ~MyMainWindow();
    void loadImage();
    static MyMap *myMainMap;
    static BoxCard *pressedcard;
    static QList<CrObject *> *myObjects;
    static int sndVol;
    static bool sndMute;

private slots:
    void sttngBtnClicked();
    void backBtnClicked();
    void battleBtnClicked();
    void quitBtnClicked();
    void resumeBtnClicked();
    void pauseBtnClicked();
    void startBtnClicked();
    void exitBtnClicked();
    void gameModeChanged();
    void switchCards();
    void changeTime();
    void reAdjustMedia();
   // void rePlayMusic();




private:
    QStackedWidget *stack;
    QMediaPlayer *mediaPlayer;
    QMediaPlaylist *playlist;
    MyMenu *menu;
    MyCard *mycard;
    MyPause *mypause;
    SingleMap *snglemap;
    DoubleMap *dblemap;
    Setting *sttng;
    QLabel *bckgrnd_img;
    QList<CrCard *> *myFighters;
    QList<BoxCard*> *myboxcard;
    QTimer *maintimer;
    QLabel *timelabel;
    QPoint mapcard_point[8] = {QPoint(20, 640), QPoint(90, 640), QPoint(160, 640),
                               QPoint(230, 640), QPoint(0, 0), QPoint(0, 0), QPoint(0, 0),
                               QPoint(0, 0)};
    int card_cost[15] = {3, 5, 2, 4, 5, 6, 7, 3, 4, 1, 4, 6, 5, 4, 5};

    int min;
    int sec1;
    int sec2;


    void setStack();
    void setConnections();
    void adjustMedia();
    void setTimer();
    void pauseMusic();
    void resumeMusic();



};


#endif //CLASHROYALE_MYMAINWINDOW_H
