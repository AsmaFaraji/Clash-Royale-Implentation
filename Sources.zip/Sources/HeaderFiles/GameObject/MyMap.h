//
// Created by asma on 7/7/16.
//

#ifndef CLASHROYALE_MYMAP_H
#define CLASHROYALE_MYMAP_H


#include <QtWidgets/qgraphicsview.h>
#include <QtWidgets/qprogressbar.h>

class MyMap: public QGraphicsView {
    Q_OBJECT
public:
    MyMap();
    ~MyMap();
    QGraphicsScene *& getScene();

    QProgressBar *&getElixirBar();
    QTimer *&getElixirTimer();
private:
    QGraphicsScene * scene;
    QProgressBar *elixirbar;
    QTimer *elixirtimer;
};


#endif //CLASHROYALE_MYMAP_H
