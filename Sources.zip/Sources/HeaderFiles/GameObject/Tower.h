//
// Created by asma on 7/3/16.
//

#ifndef CLASHROYALE_TOWER_H
#define CLASHROYALE_TOWER_H
#include <Sources/HeaderFiles/MyData.h>
#include <QtCore/qtimer.h>
#include <Sources/HeaderFiles/GameObject/Cards/Weapon.h>
#include "Sources/HeaderFiles/GameObject/CrObject.h"
class Tower : public CrObject {
Q_OBJECT
    friend class MyMainWindow;
public:
    Tower(MyData::HitPoint  = 0, MyData::HitSpeed  = 0,MyData:: Damage  = 0, MyData::Sight  = 0, MyData::Range  = 0,MyData:: Target = MyData::Ta, MyData::Type = MyData::Ty,
          QImage * = 0, const QRect & = MyData::rect, int = 0);
     ~Tower();

    CrObject *enemy;


private slots:
    void RangeChecker();
    void attack();
    void die();

private:
    QList<Weapon *> *weapon;
    QTimer *attacktimer;
    QTimer *lifetimer;
    void paused();
    void resumed();
    bool foundEnemy;
    bool InSight(CrObject *);
    bool InRange(CrObject*);





};


#endif //CLASHROYALE_TOWER_H
