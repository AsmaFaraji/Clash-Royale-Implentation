//
// Created by asma on 7/3/16.
//

#ifndef CLASHROYALE_CROBJECT_H
#define CLASHROYALE_CROBJECT_H


#include <QtCore/qobject.h>
#include <QtWidgets/qgraphicsitem.h>
#include <Sources/HeaderFiles/MyData.h>


class CrObject: public QObject, public QGraphicsPixmapItem {

Q_OBJECT
public:
    CrObject(MyData::HitPoint  = 0, MyData::HitSpeed  = 0, MyData::Damage = 0, MyData::Sight = 0, MyData::Range = 0,
             MyData::Target = MyData::Ta, MyData::Type = MyData::Ty,int = 0);

    ~CrObject();

    void setHintPoint(MyData::HitPoint);

    void setHintSpeed(MyData::HitSpeed);

    void setDamage(MyData::Damage);

    void setSight(MyData::Sight);

    void setRange(MyData::Range);

    void setTarget(MyData::Target);

    void setType(MyData::Type);
    void setLife(bool);
    void setTeam(int);


    MyData::HitPoint getHitPoint();

    MyData::HitSpeed getHitSpeed();

    MyData::Damage getDamage();

    MyData::Sight getSight();

    MyData::Range getRange();

    MyData::Target getTarget();

    MyData::Type getType();

    QPixmap*&getPixmap();
    bool isAlive();
    int getTeam();

    void loadImage(QImage * img, const QRect);

    void test();

private:
    MyData::HitPoint hitpoint;
    MyData::HitSpeed hitSpeed;
    MyData::Damage damge;
    MyData::Sight sight;
    MyData::Range range;
    MyData::Target target;
    MyData::Type type;
    QPixmap *pix;
    bool life;
    int team;

};


#endif //CLASHROYALE_CROBJECT_H
