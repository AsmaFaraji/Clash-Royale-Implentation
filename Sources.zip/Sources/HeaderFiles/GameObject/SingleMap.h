//
// Created by asma on 7/1/16.
//

#ifndef CLASHROYALE_SINGLEMAP_H
#define CLASHROYALE_SINGLEMAP_H


#include <QtCore/qobject.h>
#include<QGraphicsPixmapItem>
#include <QtWidgets/qpushbutton.h>
#include <QLabel>
#include <QtWidgets/qprogressbar.h>
#include "Tower.h"
#include "FightField.h"
#include "MyMap.h"

class SingleMap : public MyMap{
    Q_OBJECT
    friend class MyMainWindow;
    friend class FightField;
    friend class CrCard;
public:
    SingleMap();
    ~SingleMap();
    void setFightFieldTower();
    void removeFightFieldTower();

 private slots:
    void onTimeOut();

private:
    QPushButton *pause;
    QLabel *score;
    QLabel *myscore;
    Tower *tower[6];
    FightField *fightfield;
    QGraphicsPixmapItem *item[5];


    void setBar();
    void setImage();

};


#endif //CLASHROYALE_SINGLEMAP_H
