//
// Created by asma on 7/2/16.
//

#ifndef CLASHROYALE_DOUBLEMAP_H
#define CLASHROYALE_DOUBLEMAP_H


#include <QtWidgets/qgraphicsitem.h>
#include <QtWidgets/qlabel.h>
#include <QtWidgets/qpushbutton.h>
#include <QtWidgets/qprogressbar.h>
#include "Tower.h"
#include "MyMap.h"
#include "FightField.h"

class DoubleMap : public MyMap {
Q_OBJECT
    friend  class MyMainWindow;
    friend class FightField;
    friend class CrCard;



public:
    DoubleMap();
    ~DoubleMap();
    void setFightFieldTower();
    void removeFightFieldTower();

private slots:
    void onTimeOut();

private:
    QPushButton *pause;
    QLabel *score;
    QLabel *myscore;
    Tower *tower[10];
    FightField *fightfield;
    void setImage();
    void setBar();

};


#endif //CLASHROYALE_DOUBLEMAP_H
