//
// Created by asma on 7/7/16.
//

#ifndef CLASHROYALE_FIGHTFIELD_H
#define CLASHROYALE_FIGHTFIELD_H


#include <Sources/HeaderFiles/GameObject/CrObject.h>

class FightField : public CrObject {

    Q_OBJECT
public:
    FightField(QImage * = 0, const QRect & = MyData::rect);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);

 signals:
    void pressOnFightField();

private:


};


#endif //CLASHROYALE_FIGHTFIELD_H
