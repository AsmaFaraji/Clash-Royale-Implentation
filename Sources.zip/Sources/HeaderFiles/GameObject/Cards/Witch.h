//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_WITCH_H
#define CLASHROYALE_WITCH_H


#include "CrCard.h"

class Witch : public CrCard {
    Q_OBJECT
public:
    Witch(int);


};


#endif //CLASHROYALE_WITCH_H
