//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_HOGRIDER_H
#define CLASHROYALE_HOGRIDER_H


#include "CrCard.h"

class HogRider : public CrCard{
    Q_OBJECT
public:
    HogRider(int);

};


#endif //CLASHROYALE_HOGRIDER_H
