//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_RAGE_H
#define CLASHROYALE_RAGE_H


#include "CrCard.h"

class Rage: public CrCard {
    Q_OBJECT
public:
    Rage(int);
    void setRadius(MyData::Range);
    void setDuration(MyData::Duration);
    MyData::Radius getRadius();
    MyData::Duration getDuration();


private:
    MyData::Duration duration;
    MyData::Radius radius;

};


#endif //CLASHROYALE_RAGE_H
