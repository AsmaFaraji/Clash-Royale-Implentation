//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_BALLOON_H
#define CLASHROYALE_BALLOON_H

#include "CrCard.h"
class Balloon : public CrCard {
    Q_OBJECT
public:
    Balloon(int);
    ~Balloon();

};


#endif //CLASHROYALE_BALLOON_H
