//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_ROYALGIANET_H
#define CLASHROYALE_ROYALGIANET_H


#include "CrCard.h"

class RoyalGianet: public CrCard {
    Q_OBJECT
public:
    RoyalGianet(int);

};


#endif //CLASHROYALE_ROYALGIANET_H
