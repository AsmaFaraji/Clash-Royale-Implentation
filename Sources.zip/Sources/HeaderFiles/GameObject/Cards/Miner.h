//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_MINER_H
#define CLASHROYALE_MINER_H


#include "CrCard.h"

class Miner: public CrCard {
    Q_OBJECT
public:
    Miner(int);

};


#endif //CLASHROYALE_MINER_H
