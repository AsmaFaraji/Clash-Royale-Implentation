//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_VALKYRIE_H
#define CLASHROYALE_VALKYRIE_H


#include "CrCard.h"

class Valkyrie : public CrCard {
    Q_OBJECT
public:
    Valkyrie(int);
};


#endif //CLASHROYALE_VALKYRIE_H
