//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_FIRESPIRITS_H
#define CLASHROYALE_FIRESPIRITS_H


#include "CrCard.h"

class FireSpirits : public CrCard{

    Q_OBJECT
public:
    FireSpirits(int);

};


#endif //CLASHROYALE_FIRESPIRITS_H
