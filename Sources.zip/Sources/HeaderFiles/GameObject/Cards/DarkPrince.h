//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_DARKPRINCE_H
#define CLASHROYALE_DARKPRINCE_H


#include "CrCard.h"

class DarkPrince : public CrCard{
    Q_OBJECT
public:
    DarkPrince(int = 0);

};


#endif //CLASHROYALE_DARKPRINCE_H
