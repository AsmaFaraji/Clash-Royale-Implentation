//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_MINIONHORDE_H
#define CLASHROYALE_MINIONHORDE_H


#include "CrCard.h"

class MinionHorde: public CrCard{
    Q_OBJECT
public:
    MinionHorde(int);

};


#endif //CLASHROYALE_MINIONHORDE_H
