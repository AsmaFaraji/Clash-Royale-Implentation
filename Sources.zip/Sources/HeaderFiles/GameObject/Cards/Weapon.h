//
// Created by asma on 7/15/16.
//

#ifndef CLASHROYALE_WEAPON_H
#define CLASHROYALE_WEAPON_H


#include <Sources/HeaderFiles/GameObject/CrObject.h>

class Weapon : public CrObject{
    Q_OBJECT;
    friend class CrCard;
    friend class Tower;
    friend  class MyMainWindow;
public:
    Weapon(bool,double = 0, double = 0, double = 0, double = 0);
    ~Weapon();

private slots:
    void burst();

private:
    bool isFire;
    bool isAlive;
    double beginX;
    double beginY;
    double endX;
    double endY;
    double slope;
    QTimer * timer;
    void paused();
    void resumed();
    void transfer(double , double);

};


#endif //CLASHROYALE_WEAPON_H
