//
// Created by asma on 7/12/16.
//

#ifndef CLASHROYALE_BOXCARD_H
#define CLASHROYALE_BOXCARD_H


#include <QtWidgets/qgraphicsitem.h>
#include <QObject>
class BoxCard : public QObject,public QGraphicsPixmapItem{
    Q_OBJECT
friend class MyMainWindow;
public:
    BoxCard(QImage* = 0, int n = 0, int  = 0);
    ~BoxCard();
    void appear(QPoint&);
    void disappear();
    int getCharacter() const;
    int getCost() const;
private:
    QImage *img;
    QPixmap *pix;
    bool inBox;
    int cost;
    void mousePressEvent(QGraphicsSceneMouseEvent *);

    int n;

};


#endif //CLASHROYALE_BOXCARD_H
