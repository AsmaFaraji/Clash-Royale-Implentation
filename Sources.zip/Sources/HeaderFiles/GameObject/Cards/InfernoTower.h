//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_INFERNOTOWER_H
#define CLASHROYALE_INFERNOTOWER_H


#include "CrCard.h"

class InfernoTower : public CrCard {

    Q_OBJECT
public:
    InfernoTower(int);
    void setLifeTime(MyData::LifeTime);
    MyData::LifeTime getLifeTime();


private:
    MyData::LifeTime lifetime;

};


#endif //CLASHROYALE_INFERNOTOWER_H
