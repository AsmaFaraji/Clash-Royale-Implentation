//
// Created by asma on 7/4/16.
//

#ifndef CLASHROYALE_CRCARD_H
#define CLASHROYALE_CRCARD_H

#include "Sources/HeaderFiles/GameObject/CrObject.h"
#include "Weapon.h"
#include <Sources/HeaderFiles/MyData.h>
#include <QtCore/qtimer.h>

class CrCard :public  CrObject {
Q_OBJECT
friend class MyMainWindow;
public:
    CrCard(MyData::HitPoint  = 0, MyData::HitSpeed  = 0, MyData::Damage  = 0, MyData::Sight  = 0, MyData::Range  = 0,
           MyData::DeployTime = 0, MyData::Cost = 1,MyData::Count = 0, MyData::Speed = MyData::Sp,MyData::FightTerittory = MyData::FT,
           MyData::Target = MyData::Ta, MyData::Type = MyData::Ty, int = 0);

    ~CrCard();

    void setDeployTime(MyData::DeployTime);

    void setCost(MyData::Cost);

    void setCount(MyData::Count);

    void setFightTerittory(MyData::FightTerittory);

    void setSpeed(MyData::Speed);

    MyData::DeployTime getDeployTime();

    MyData::Cost getCost();

    MyData::Count getCout();

    MyData::FightTerittory getFightTerittory();

    MyData::Speed getSpeed();
    bool& getFight() ;



private slots:
    void move();
    void RangeChecker();
    void go();
    void attack();
    void die();





private:
    QList<Weapon*> *weapon;
    QTimer *movetimer;
    QTimer *rangetimer;
    QTimer *attacktimer;
    QTimer *starttimer;
    QTimer *lifetimer;
    MyData::Speed speed;
    MyData::DeployTime deployTime;
    MyData::Cost cost;
    MyData::Count count;
    MyData::FightTerittory fightterittory;
    double dx;
    double dy;
    double ang;
    bool fight;
    bool foundEnemy;
    bool stop;
    CrObject * enemy;



    void transfer(double, double);
    void moveToRiver();
    void moveToTower();
    void moveToEnemy();
    bool InRange(CrObject*);
    bool InSight(CrObject *);
    void paused();
    void resumed();
    double PI();



};


#endif //CLASHROYALE_CRCARD_H
