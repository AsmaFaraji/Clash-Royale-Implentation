//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_ZAP_H
#define CLASHROYALE_ZAP_H


#include "CrCard.h"

class Zap : public  CrCard{
    Q_OBJECT
public:
    Zap(int);
    void setRadius(MyData::Radius);
    void setCrownDamage(MyData::CrownDamage);
    MyData::Radius getRadius();
    MyData::CrownDamage getCrownDamage();


private:
    MyData::Radius radius;
    MyData::CrownDamage crowndamage;




};


#endif //CLASHROYALE_ZAP_H
