//
// Created by asma on 7/4/16.
//

#ifndef CLASHROYALE_LAVAHOUND_H
#define CLASHROYALE_LAVAHOUND_H


#include "CrCard.h"

class LavaHound : public CrCard {
public:
    LavaHound(int);



};


#endif //CLASHROYALE_LAVAHOUND_H
