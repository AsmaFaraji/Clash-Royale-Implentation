//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_FURNANCE_H
#define CLASHROYALE_FURNANCE_H

#include "CrCard.h"
class Furnance : public CrCard {
    Q_OBJECT
public:
    Furnance(int);


    void setLifeTime(MyData::LifeTime);
    MyData::LifeTime getLifeTime();


private:
    MyData::LifeTime lifetime;

};


#endif //CLASHROYALE_FURNANCE_H
