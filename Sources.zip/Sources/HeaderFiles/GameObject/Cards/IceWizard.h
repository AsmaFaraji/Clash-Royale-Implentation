//
// Created by asma on 7/5/16.
//

#ifndef CLASHROYALE_ICEWIZARD_H
#define CLASHROYALE_ICEWIZARD_H


#include "CrCard.h"

class IceWizard: public CrCard {
    Q_OBJECT
public:
    IceWizard(int);
};


#endif //CLASHROYALE_ICEWIZARD_H
